/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Box, Layers3, Save, Download, PanelLeftClose, PanelLeftOpen, Eye, EyeOff, LockKeyhole, UnlockKeyhole, Plus, HelpCircle, X, SplitSquareHorizontal, Square, RotateCcw, ChevronRight, MousePointer2, Check, Search, Focus, Maximize2 } from 'lucide-react';
import {
  CadShape,
  CameraViewId,
  PrimitivePresetType,
  BooleanOperationType,
  BooleanOperationResult,
  createPrecisionDemoScene,
  createPrimitiveShape,
  createCleanTBeamPoints,
  translateShape2D,
  computeBooleanShapes,
  computeBounds2D,
  mirrorShape2D,
  createRectArrayCopies,
  createPolarArrayCopies,
} from './utils/cadEngine';
import {
  HistoryState,
  createHistoryState,
  pushHistoryState,
  replaceHistoryPresent,
  undoHistoryState,
  redoHistoryState,
  canUndo,
  canRedo,
  isSameHistoryItem,
} from './utils/historyManager';
import { Cad2DCanvas, DrawTool2D } from './components/Cad2DCanvas';
import { Cad3DViewport, Cad3DExporterApi } from './components/Cad3DViewport';
import { BottomControlDock } from './components/BottomControlDock';
import { ExportViewsModal } from './components/ExportViewsModal';
import { Inspector } from './components/Inspector';
import { CommandPalette, CadCommand } from './components/CommandPalette';
import { DxfImportDialog } from './components/DxfImportDialog';
import { FileOpenMenu } from './components/FileOpenMenu';
import { PrecisionTransform, transformSelectedShapes } from './utils/precisionTransforms';
import { PrecisionPrimitiveSpec, createPrecisionPrimitive } from './utils/precisionPrimitives';
import {
  downloadProject,
  pickProjectFile,
  saveProjectToLocal,
  loadProjectFromLocal,
} from './utils/projectFile';

export type WorkspaceLayoutMode = 'split' | '2d-only' | '3d-only';

export default function App() {
  // 启动时优先从本机自动存档恢复上次画布，无存档则载入示例场景
  const [bootstrap] = useState(() => {
    const restored = loadProjectFromLocal();
    return {
      shapes: restored ?? createPrecisionDemoScene(),
      wasRestored: restored !== null,
    };
  });
  const [history, setHistory] = useState<HistoryState<CadShape[]>>(() =>
    createHistoryState(bootstrap.shapes),
  );
  const shapes = history.present;
  const historyRef = useRef(history);
  historyRef.current = history;
  const dragHistoryRef = useRef<HistoryState<CadShape[]> | null>(null);
  const canvasInteractionRef = useRef(false);
  const [showRestoreNotice, setShowRestoreNotice] = useState<boolean>(
    bootstrap.wasRestored,
  );

  const [selectedIds, setSelectedIds] = useState<string[]>(bootstrap.shapes[0] ? [bootstrap.shapes[0].id] : []);
  const selectedId = selectedIds[0] ?? null;

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [helpOpen, setHelpOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [dxfFile, setDxfFile] = useState<{ name: string; text: string } | null>(null);
  const dxfInputRef = useRef<HTMLInputElement>(null);
  const [objectQuery, setObjectQuery] = useState('');
  const [fitRequest, setFitRequest] = useState(0);
  const [panelRequest, setPanelRequest] = useState<{ panel: 'create' | 'properties' | 'boolean' | 'transform'; nonce: number }>();
  const [saveStatus, setSaveStatus] = useState<'pending' | 'saved' | 'failed'>('pending');
  const [activeTool, setActiveTool] = useState<DrawTool2D>('select');
  const [layoutMode, setLayoutMode] = useState<WorkspaceLayoutMode>('3d-only');
  const [activeCameraView, setActiveCameraView] =
    useState<CameraViewId>('perspective');
  const [defaultZHeight, setDefaultZHeight] = useState<number>(30);
  const [snapEnabled, setSnapEnabled] = useState<boolean>(true);
  const [gridStep, setGridStep] = useState<number>(2);
  const [wireframeOverlay, setWireframeOverlay] = useState<boolean>(true);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [exporterApi, setExporterApi] = useState<Cad3DExporterApi | null>(null);

  const handleBeginGeometryDrag = useCallback(() => {
    if (!dragHistoryRef.current) dragHistoryRef.current = historyRef.current;
  }, []);
  const handleCancelGeometryDrag = useCallback(() => {
    if (dragHistoryRef.current) setHistory(dragHistoryRef.current);
    dragHistoryRef.current = null;
  }, []);
  const handleEndGeometryDrag = useCallback(() => {
    const before = dragHistoryRef.current;
    dragHistoryRef.current = null;
    if (before) setHistory((current) => isSameHistoryItem(current.present, before.present) ? before : current);
  }, []);
  const handleCanvasInteractionChange = useCallback((active: boolean) => { canvasInteractionRef.current = active; }, []);

  // Prune any deleted IDs from selectedIds when undo/redo/delete happens
  useEffect(() => {
    setSelectedIds((prev) => {
      const valid = prev.filter((id) => shapes.some((s) => s.id === id));
      if (valid.length !== prev.length) {
        return valid;
      }
      return prev;
    });
  }, [shapes]);

  // Auto-save the whole project to localStorage (debounced) so a refresh never loses work
  useEffect(() => {
    setSaveStatus('pending');
    const timer = setTimeout(() => {
      const result = saveProjectToLocal(shapes);
      setSaveStatus(result === false ? 'failed' : 'saved');
    }, 800);
    return () => clearTimeout(timer);
  }, [shapes]);

  useEffect(() => {
    const flushAutosave = () => { saveProjectToLocal(shapes); };
    window.addEventListener('pagehide', flushAutosave);
    return () => window.removeEventListener('pagehide', flushAutosave);
  }, [shapes]);

  // Auto-dismiss the "restored from autosave" toast
  useEffect(() => {
    if (!showRestoreNotice) return;
    const timer = setTimeout(() => setShowRestoreNotice(false), 4500);
    return () => clearTimeout(timer);
  }, [showRestoreNotice]);

  const handleSelectSingleShape = useCallback((id: string | null) => {
    setSelectedIds(id ? [id] : []);
  }, []);

  const handleSelectShape = useCallback((id: string | null, additive = false) => {
    setSelectedIds((ids) => {
      if (!additive) return id ? [id] : [];
      if (!id) return ids;
      return ids.includes(id) ? ids.filter((selected) => selected !== id) : [...ids, id];
    });
  }, []);

  const handleSelectAllShapes = useCallback(() => {
    const allVisibleIds = shapes.filter((s) => s.visible).map((s) => s.id);
    setSelectedIds(allVisibleIds);
    setActiveTool('select');
  }, [shapes]);

  const handleUndo = useCallback(() => {
    setHistory((prev) => undoHistoryState(prev));
  }, []);

  const handleRedo = useCallback(() => {
    setHistory((prev) => redoHistoryState(prev));
  }, []);

  const handleDeleteShape = useCallback(
    (id?: string) => {
      setHistory((prev) => {
        const idsToRemove = new Set(
          id && !selectedIds.includes(id)
            ? [id]
            : selectedIds.length > 0
              ? selectedIds
              : id
                ? [id]
                : [],
        );
        if (idsToRemove.size === 0) return prev;
        const next = prev.present.filter((s) => !idsToRemove.has(s.id) || s.locked);
        if (next.length === prev.present.length) return prev;
        setSelectedIds(next[next.length - 1] ? [next[next.length - 1].id] : []);
        return pushHistoryState(prev, next);
      });
    },
    [selectedIds],
  );

  const handleUpdateShape = useCallback(
    (updated: CadShape, transient = false) => {
      setHistory((prev) => {
        const nextShapes = prev.present.map((s) =>
          s.id === updated.id && !s.locked ? updated : s,
        );
        return transient
          ? replaceHistoryPresent(prev, nextShapes)
          : pushHistoryState(prev, nextShapes);
      });
    },
    [],
  );

  const handleUpdateMultipleShapes = useCallback(
    (nextShapes: CadShape[], transient = false) => {
      setHistory((prev) => {
        const protectedShapes = prev.present.map((shape) => shape.locked ? shape : nextShapes.find((next) => next.id === shape.id) ?? shape);
        return transient ? replaceHistoryPresent(prev, protectedShapes) : pushHistoryState(prev, protectedShapes);
      });
    },
    [],
  );

  const handleCreateShape = useCallback((newShape: CadShape) => {
    setHistory((prev) => pushHistoryState(prev, [...prev.present, newShape]));
    setSelectedIds([newShape.id]);
  }, []);

  const handleDuplicateShape = useCallback(
    (id?: string) => {
      setHistory((prev) => {
        const targetIds =
          selectedIds.length > 1
            ? selectedIds
            : id
              ? [id]
              : selectedIds;
        if (targetIds.length === 0) return prev;
        const copies: CadShape[] = [];
        const usedNames = new Set(prev.present.map((shape) => shape.name));
        targetIds.forEach((tid, idx) => {
          const target = prev.present.find((s) => s.id === tid);
          if (!target) return;
          const shifted = translateShape2D(target, 14, -14);
          const baseName = `${target.name} (副本)`;
          let name = baseName;
          let suffix = 2;
          while (usedNames.has(name)) name = `${baseName} (${suffix++})`;
          usedNames.add(name);
          copies.push({
            ...shifted,
            id: `shape-copy-${Date.now()}-${idx}`,
            name,
            locked: false,
            visible: true,
            booleanMeta: undefined,
          });
        });
        if (copies.length === 0) return prev;
        setSelectedIds(copies.map((c) => c.id));
        return pushHistoryState(prev, [...prev.present, ...copies]);
      });
    },
    [selectedIds],
  );

  const handleAddPrimitive = useCallback(
    (preset: PrimitivePresetType) => {
      setHistory((prev) => {
        const nextIndex = prev.present.length + 1;
        const created = createPrimitiveShape(preset, nextIndex);
        if (preset === 't-beam') {
          created.points = createCleanTBeamPoints(
            ((nextIndex - 1) % 4) * 8,
            ((nextIndex - 1) % 4) * 8,
          );
        }
        created.zHeight = defaultZHeight;
        setSelectedIds([created.id]);
        return pushHistoryState(prev, [...prev.present, created]);
      });
      setActiveTool('select');
    },
    [defaultZHeight],
  );

  const [booleanFeedback, setBooleanFeedback] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  // Boolean preview state: 预览结果只以虚线显示，确认后才进入历史记录
  const [booleanPreview, setBooleanPreview] = useState<{
    op: BooleanOperationType;
    targetId: string;
    toolId: string;
    sourceA: CadShape;
    sourceB: CadShape;
    resultShape: CadShape;
    message: string;
  } | null>(null);

  const handleResetDemo = useCallback(() => {
    const starter = createPrecisionDemoScene();
    setHistory((prev) => pushHistoryState(prev, starter));
    setSelectedIds(starter[0] ? [starter[0].id] : []);
    setLayoutMode('3d-only');
    setActiveTool('select');
    setBooleanFeedback(null);
    setBooleanPreview(null);
  }, []);

  const handleNewEmptyModel = useCallback(() => {
    setHistory((prev) => pushHistoryState(prev, []));
    setSelectedIds([]);
    setActiveTool('rect');
    setLayoutMode('2d-only');
    setBooleanFeedback(null);
    setBooleanPreview(null);
  }, []);

  const handleBooleanOperation = useCallback(
    (
      op: BooleanOperationType,
      customTargetId?: string,
      customToolId?: string,
    ): BooleanOperationResult => {
      const targetId = customTargetId ?? selectedIds[0];
      const toolId =
        customToolId ??
        selectedIds[1] ??
        shapes.find((s) => s.visible && s.id !== targetId)?.id;

      const shapeA = shapes.find((s) => s.id === targetId);
      const shapeB = shapes.find((s) => s.id === toolId);

      if (!shapeA || !shapeB || shapeA.id === shapeB.id) {
        const res: BooleanOperationResult = {
          ok: false,
          operation: op,
          resultShape: null,
          wasAutoAligned: false,
          message: '请至少确保画布中有 2 个不同的图形再执行布尔运算。',
        };
        setBooleanFeedback({ ok: false, message: res.message });
        return res;
      }

      if (shapeA.locked || shapeB.locked) {
        const res: BooleanOperationResult = { ok: false, operation: op, resultShape: null, wasAutoAligned: false, message: '请先解锁两个源对象，再执行布尔运算。' };
        setBooleanFeedback({ ok: false, message: res.message });
        return res;
      }

      const res = computeBooleanShapes(shapeA, shapeB, op);

      if (res.ok && res.resultShape) {
        const created = res.resultShape;
        // 结果实体化：原始操作数不删除，仅隐藏保留，结果图形带 booleanMeta 可还原
        setHistory((prev) => {
          const nextShapes = prev.present
            .map((s) =>
              s.id === shapeA.id || s.id === shapeB.id
                ? { ...s, visible: false }
                : s,
            )
            .concat(created);
          return pushHistoryState(prev, nextShapes);
        });
        setSelectedIds([created.id]);
        setActiveTool('select');
        setBooleanPreview(null);
      }
      setBooleanFeedback({ ok: res.ok, message: res.message });
      return res;
    },
    [shapes, selectedIds],
  );

  const handleSaveProject = useCallback(() => {
    downloadProject(shapes);
    setBooleanFeedback({ ok: true, message: '工程文件已生成，请查看浏览器下载。' });
  }, [shapes]);

  const handleOpenProject = useCallback(async () => {
    try {
      const loaded = await pickProjectFile();
      setHistory(createHistoryState(loaded));
      setSelectedIds(loaded[0] ? [loaded[0].id] : []);
      setActiveTool('select');
      setBooleanFeedback({
        ok: true,
        message: `已打开工程：载入 ${loaded.length} 个图形。`,
      });
      saveProjectToLocal(loaded);
    } catch (err) {
      if (err instanceof Error && err.message === '已取消选择') return;
      setBooleanFeedback({
        ok: false,
        message: `打开工程失败：${err instanceof Error ? err.message : '未知错误'}`,
      });
    }
  }, []);

  const handleDxfFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;
    try {
      if (file.size > 5 * 1024 * 1024) throw new Error('DXF 文件超过 5 MB，请先精简轮廓。');
      setDxfFile({ name: file.name, text: await file.text() });
    } catch (error) {
      setBooleanFeedback({ ok: false, message: error instanceof Error ? error.message : '无法读取 DXF 文件。' });
    }
  };

  const handleImportDxf = useCallback((imported: CadShape[]) => {
    const usedNames = new Set(historyRef.current.present.map((shape) => shape.name));
    const additions = imported.map((shape) => {
      let name = shape.name;
      let suffix = 2;
      while (usedNames.has(name)) name = `${shape.name} (${suffix++})`;
      usedNames.add(name);
      return { ...shape, id: `shape-dxf-${crypto.randomUUID()}`, name };
    });
    if (!additions.length) return;
    setHistory((previous) => pushHistoryState(previous, [...previous.present, ...additions]));
    setSelectedIds(additions.map((shape) => shape.id));
    setActiveTool('select');
    setLayoutMode('2d-only');
    setBooleanPreview(null);
    setFitRequest((value) => value + 1);
    setBooleanFeedback({ ok: true, message: `已追加 ${additions.length} 个 DXF 轮廓，可用 Ctrl + Z 撤销本次导入。` });
  }, []);

  const handleBooleanPreview = useCallback(
    (op: BooleanOperationType, targetId: string, toolId: string) => {
      const shapeA = shapes.find((s) => s.id === targetId);
      const shapeB = shapes.find((s) => s.id === toolId);
      if (!shapeA || !shapeB || shapeA.id === shapeB.id) {
        setBooleanFeedback({
          ok: false,
          message: '请先选择 2 个不同的图形再预览布尔运算。',
        });
        return false;
      }
      if (shapeA.locked || shapeB.locked) {
        setBooleanFeedback({ ok: false, message: '请先解锁两个源对象，再预览布尔运算。' });
        return false;
      }
      const res = computeBooleanShapes(shapeA, shapeB, op);
      if (res.ok && res.resultShape) {
        setBooleanPreview({
          op,
          targetId,
          toolId,
          sourceA: shapeA,
          sourceB: shapeB,
          resultShape: res.resultShape,
          message: res.message,
        });
        setBooleanFeedback(null);
        setLayoutMode('2d-only');
        setActiveTool('select');
        return true;
      } else {
        setBooleanPreview(null);
        setBooleanFeedback({ ok: false, message: res.message });
        return false;
      }
    },
    [shapes],
  );

  const handleCommitBooleanPreview = useCallback(() => {
    if (!booleanPreview) return;
    if (!isSameHistoryItem(shapes.find((s) => s.id === booleanPreview.targetId), booleanPreview.sourceA) ||
        !isSameHistoryItem(shapes.find((s) => s.id === booleanPreview.toolId), booleanPreview.sourceB)) {
      setBooleanPreview(null);
      setBooleanFeedback({ ok: false, message: '源对象已改变，请重新预览布尔结果。' });
      return;
    }
    const { resultShape, targetId, toolId, message } = booleanPreview;
    setHistory((prev) => {
      const nextShapes = prev.present
        .map((s) =>
          s.id === targetId || s.id === toolId ? { ...s, visible: false } : s,
        )
        .concat(resultShape);
      return pushHistoryState(prev, nextShapes);
    });
    setSelectedIds([resultShape.id]);
    setActiveTool('select');
    setBooleanPreview(null);
    setBooleanFeedback({ ok: true, message });
  }, [booleanPreview, shapes]);

  const handleCancelBooleanPreview = useCallback(() => {
    setBooleanPreview(null);
  }, []);

  // 源对象的尺寸、位置或可见性改变后，旧预览不能继续应用。
  useEffect(() => {
    if (!booleanPreview) return;
    const sourceA = shapes.find((s) => s.id === booleanPreview.targetId);
    const sourceB = shapes.find((s) => s.id === booleanPreview.toolId);
    if (!isSameHistoryItem(sourceA, booleanPreview.sourceA) || !isSameHistoryItem(sourceB, booleanPreview.sourceB)) {
      setBooleanPreview(null);
      setBooleanFeedback({ ok: false, message: '源对象已改变，请重新预览布尔结果。' });
    }
  }, [shapes, booleanPreview]);

  // 还原布尔：删除结果图形，恢复两个操作数的可见性
  const handleRestoreBoolean = useCallback(
    (resultId: string) => {
      const resultShape = shapes.find((s) => s.id === resultId);
      const meta = resultShape?.booleanMeta;
      if (!meta) return;
      if (resultShape.locked) {
        setBooleanFeedback({ ok: false, message: '请先解锁布尔结果，再还原源对象。' });
        return;
      }
      setHistory((prev) => {
        const nextShapes = prev.present
          .filter((s) => s.id !== resultId)
          .map((s) =>
            s.id === meta.targetId || s.id === meta.toolId
              ? { ...s, visible: true }
              : s,
          );
        return pushHistoryState(prev, nextShapes);
      });
      setSelectedIds([meta.targetId]);
      setBooleanFeedback({
        ok: true,
        message: `已还原：删除布尔结果并恢复显示「${meta.targetName}」与「${meta.toolName}」。`,
      });
    },
    [shapes],
  );

  // 镜像：原地绕自身中心翻转，或绕原点轴线生成镜像副本
  const handleMirrorShapes = useCallback(
    (axis: 'x' | 'y', asCopy: boolean) => {
      const targets = shapes.filter(
        (s) => selectedIds.includes(s.id) && s.visible && !s.locked,
      );
      if (targets.length === 0) {
        setBooleanFeedback({
          ok: false,
          message: '请先选中至少 1 个未锁定图形再执行镜像。',
        });
        return;
      }
      setHistory((prev) => {
        if (asCopy) {
          const copies = targets.map((s, i) => {
            const mirrored = mirrorShape2D(s, axis, 0);
            return {
              ...mirrored,
              id: `shape-mirror-${Date.now()}-${i}`,
              name: `${s.name.replace(/\s*\(.*\)/, '')} (镜像)`,
              booleanMeta: undefined,
              locked: false,
            };
          });
          setSelectedIds(copies.map((c) => c.id));
          return pushHistoryState(prev, [...prev.present, ...copies]);
        }
        const idSet = new Set(targets.map((t) => t.id));
        const next = prev.present.map((s) => {
          if (!idSet.has(s.id)) return s;
          const b = computeBounds2D(s.points);
          // 以包围盒中心为轴，镜像后包围盒位置严格不变
          const pivot =
            axis === 'x' ? (b.minX + b.maxX) / 2 : (b.minY + b.maxY) / 2;
          return mirrorShape2D(s, axis, pivot);
        });
        return pushHistoryState(prev, next);
      });
      setBooleanFeedback({
        ok: true,
        message: asCopy
          ? `已生成 ${targets.length} 个镜像副本（绕原点${axis === 'x' ? '竖直轴 X=0' : '水平轴 Y=0'}翻转）。`
          : `已原地${axis === 'x' ? '左右' : '上下'}镜像 ${targets.length} 个图形。`,
      });
    },
    [shapes, selectedIds],
  );

  // 矩形阵列
  const handleRectArray = useCallback(
    (rows: number, cols: number, gapX: number, gapY: number) => {
      const targets = shapes.filter(
        (s) => selectedIds.includes(s.id) && s.visible && !s.locked,
      );
      const copies = createRectArrayCopies(targets, { rows, cols, gapX, gapY });
      if (copies.length === 0) {
        setBooleanFeedback({
          ok: false,
          message: '阵列未生效：请先选中图形，并确保行×列大于 1×1。',
        });
        return;
      }
      setHistory((prev) => pushHistoryState(prev, [...prev.present, ...copies]));
      setSelectedIds(copies.map((c) => c.id));
      setBooleanFeedback({
        ok: true,
        message: `已生成矩形阵列 ${cols}列×${rows}行（间距 X:${gapX} / Y:${gapY}mm），新增 ${copies.length} 个副本并已选中。`,
      });
    },
    [shapes, selectedIds],
  );

  // 环形阵列
  const handlePolarArray = useCallback(
    (count: number, totalAngleDeg: number, centerX: number, centerY: number) => {
      const targets = shapes.filter(
        (s) => selectedIds.includes(s.id) && s.visible && !s.locked,
      );
      const copies = createPolarArrayCopies(targets, {
        count,
        totalAngleDeg,
        center: { x: centerX, y: centerY },
      });
      if (copies.length === 0) {
        setBooleanFeedback({
          ok: false,
          message: '环形阵列未生效：请先选中图形，数量需 ≥ 2。',
        });
        return;
      }
      setHistory((prev) => pushHistoryState(prev, [...prev.present, ...copies]));
      setSelectedIds(copies.map((c) => c.id));
      setBooleanFeedback({
        ok: true,
        message: `已生成环形阵列 ×${count}（总角 ${totalAngleDeg}°，中心 ${centerX},${centerY}），新增 ${copies.length} 个副本并已选中。`,
      });
    },
    [shapes, selectedIds],
  );

  const handleObjectVisibility = useCallback((id: string, visible: boolean) => {
    setHistory((prev) => pushHistoryState(prev, prev.present.map((shape) => shape.id === id ? { ...shape, visible } : shape)));
  }, []);

  const handleLockObjects = useCallback((ids: string[], locked: boolean) => {
    setHistory((prev) => pushHistoryState(prev, prev.present.map((shape) => ids.includes(shape.id) ? { ...shape, locked } : shape)));
  }, []);

  const handleVisibilityCommand = useCallback((mode: 'hide-selected' | 'isolate' | 'show-all') => {
    setHistory((prev) => pushHistoryState(prev, prev.present.map((shape) => ({ ...shape, visible: mode === 'show-all' ? true : mode === 'isolate' ? selectedIds.includes(shape.id) : selectedIds.includes(shape.id) ? false : shape.visible }))));
  }, [selectedIds]);

  const handleTransformSelection = useCallback((operation: PrecisionTransform) => {
    try {
      const result = transformSelectedShapes(shapes, selectedIds, operation);
      if (!result.changed) {
        setBooleanFeedback({ ok: false, message: '没有产生变化：请选择可见、未锁定的对象，并输入有效变换。' });
        return false;
      }
      setHistory((prev) => pushHistoryState(prev, result.shapes));
      setSelectedIds(result.selectedIds);
      const skipped = shapes.filter((shape) => selectedIds.includes(shape.id) && shape.locked).length;
      setBooleanFeedback({ ok: true, message: `已${operation.copy ? '复制并' : ''}${operation.kind === 'move' ? '移动' : operation.kind === 'rotate' ? '旋转' : '缩放'} ${result.changed} 个对象${skipped ? `，跳过 ${skipped} 个锁定对象` : ''}，可用 Ctrl + Z 撤销。` });
      return true;
    } catch (error) {
      setBooleanFeedback({ ok: false, message: error instanceof Error ? error.message : '变换未完成，请检查参数。' });
      return false;
    }
  }, [shapes, selectedIds]);

  const handleCreatePrecisionPrimitive = useCallback((spec: PrecisionPrimitiveSpec) => {
    try {
      const shape = createPrecisionPrimitive(spec);
      const baseName = shape.name;
      let suffix = 2;
      while (shapes.some((existing) => existing.name === shape.name)) shape.name = `${baseName} (${suffix++})`;
      handleCreateShape(shape);
      setActiveTool('select');
      setBooleanFeedback({ ok: true, message: `已按尺寸创建${spec.kind === 'box' ? '长方体' : '圆柱体'}。` });
      setFitRequest((value) => value + 1);
      return true;
    } catch (error) {
      setBooleanFeedback({ ok: false, message: error instanceof Error ? error.message : '创建失败，请检查尺寸。' });
      return false;
    }
  }, [handleCreateShape, shapes]);

  const handleChangeTool = useCallback((tool: DrawTool2D) => {
    setActiveTool(tool);
    if (tool !== 'select') setLayoutMode('2d-only');
  }, []);

  const openToolPanel = useCallback((panel: 'create' | 'properties' | 'boolean' | 'transform') => {
    setPanelRequest((previous) => ({ panel, nonce: (previous?.nonce ?? 0) + 1 }));
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.isComposing || event.defaultPrevented) return;
      const key = event.key.toLowerCase();
      const modifier = event.ctrlKey || event.metaKey;
      if (canvasInteractionRef.current && key !== 'escape') { event.preventDefault(); return; }
      if (modifier && key === 'k' && !helpOpen && !isExportModalOpen && !dxfFile) {
        event.preventDefault(); setCommandOpen((open) => !open); return;
      }
      if (helpOpen || isExportModalOpen || commandOpen || dxfFile) return;
      const target = event.target as HTMLElement | null;
      const editing = Boolean(target?.closest('input, textarea, select, [contenteditable="true"]'));
      if (modifier && key === 's') {
        event.preventDefault();
        if (editing) target?.blur();
        requestAnimationFrame(() => {
          downloadProject(historyRef.current.present);
          setBooleanFeedback({ ok: true, message: '工程文件已生成，请查看浏览器下载。' });
        });
        return;
      }
      if (editing || event.altKey) return;
      if (modifier) {
        if (key === 'z') { event.preventDefault(); event.shiftKey ? handleRedo() : handleUndo(); }
        else if (key === 'y') { event.preventDefault(); handleRedo(); }
        else if (key === 'a') { event.preventDefault(); handleSelectAllShapes(); }
        else if (key === 'd') { event.preventDefault(); handleDuplicateShape(); }
        return;
      }
      const shortcuts: Record<string, DrawTool2D> = { v: 'select', l: 'line', r: 'rect', c: 'circle', p: 'polyline', m: 'measure' };
      if (shortcuts[key]) { event.preventDefault(); handleChangeTool(shortcuts[key]); }
      else if (key === 'f') { event.preventDefault(); setFitRequest((value) => value + 1); }
      else if (key === 'delete' || key === 'backspace') { event.preventDefault(); handleDeleteShape(); }
      else if (key === 'escape') { event.preventDefault(); setBooleanPreview(null); setSelectedIds([]); setActiveTool('select'); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [commandOpen, helpOpen, isExportModalOpen, dxfFile, handleUndo, handleRedo, handleSelectAllShapes, handleDuplicateShape, handleDeleteShape, handleChangeTool]);

  const selectedEditableCount = shapes.filter((shape) => selectedIds.includes(shape.id) && !shape.locked).length;
  const commands: CadCommand[] = [
    { id: 'create', label: '按尺寸创建长方体 / 圆柱', group: '创建', keywords: 'box cylinder 坐标 精确 参数', run: () => openToolPanel('create') },
    ...([{ id: 'select', label: '选择对象', key: 'V' }, { id: 'rect', label: '绘制矩形', key: 'R' }, { id: 'circle', label: '绘制圆形', key: 'C' }, { id: 'line', label: '绘制直线墙', key: 'L' }, { id: 'polyline', label: '绘制多边形', key: 'P' }, { id: 'measure', label: 'XY 两点测量', key: 'M' }] as const).map((tool) => ({ id: tool.id, label: tool.label, group: '草图', shortcut: tool.key, run: () => handleChangeTool(tool.id) })),
    { id: 'transform', label: '精确移动 / 旋转 / 等比缩放', group: '修改', keywords: 'move rotate scale 复制 变换', disabled: selectedEditableCount === 0, run: () => openToolPanel('transform') },
    { id: 'properties', label: '编辑尺寸与对齐', group: '修改', disabled: selectedIds.length === 0, run: () => openToolPanel('properties') },
    { id: 'boolean', label: '布尔并集 / 交集 / 差集', group: '修改', run: () => openToolPanel('boolean') },
    { id: 'duplicate', label: '复制所选对象', group: '修改', shortcut: 'Ctrl D', disabled: selectedIds.length === 0, run: () => handleDuplicateShape() },
    { id: 'delete', label: '删除未锁定的所选对象', group: '修改', shortcut: 'Delete', disabled: selectedEditableCount === 0, run: () => handleDeleteShape() },
    { id: 'undo', label: '撤销', group: '编辑', shortcut: 'Ctrl Z', disabled: !canUndo(history), run: handleUndo },
    { id: 'redo', label: '重做', group: '编辑', shortcut: 'Ctrl Y', disabled: !canRedo(history), run: handleRedo },
    { id: 'lock', label: '锁定所选对象', group: '对象', disabled: selectedIds.length === 0, run: () => handleLockObjects(selectedIds, true) },
    { id: 'unlock', label: '解锁所选对象', group: '对象', disabled: selectedIds.length === 0, run: () => handleLockObjects(selectedIds, false) },
    { id: 'isolate', label: '仅显示所选对象', group: '对象', keywords: '隔离 isolate', disabled: selectedIds.length === 0, run: () => handleVisibilityCommand('isolate') },
    { id: 'hide', label: '隐藏所选对象', group: '对象', disabled: selectedIds.length === 0, run: () => handleVisibilityCommand('hide-selected') },
    { id: 'show', label: '显示全部对象', group: '对象', run: () => handleVisibilityCommand('show-all') },
    { id: 'fit', label: '适合当前视图', group: '视图', shortcut: 'F', run: () => setFitRequest((value) => value + 1) },
    { id: 'model', label: '切换三维模型', group: '视图', run: () => setLayoutMode('3d-only') },
    { id: 'sketch', label: '切换二维草图', group: '视图', run: () => setLayoutMode('2d-only') },
    { id: 'split', label: '切换双视图', group: '视图', run: () => setLayoutMode('split') },
    { id: 'save', label: '保存工程文件', group: '文件', shortcut: 'Ctrl S', run: handleSaveProject },
    { id: 'open', label: '打开工程文件', group: '文件', run: handleOpenProject },
    { id: 'import-dxf', label: '导入 DXF 二维轮廓', group: '文件', keywords: 'import CAD 图纸 拉伸', run: () => dxfInputRef.current?.click() },
    { id: 'export', label: '导出 STL / OBJ / DXF / SVG / 图纸', group: '文件', run: () => setIsExportModalOpen(true) },
  ];
  const visibleCount = shapes.filter((shape) => shape.visible).length;
  const filteredShapes = shapes.filter((shape) => shape.name.toLowerCase().includes(objectQuery.trim().toLowerCase()));

  return (
    <div className="cad-app">
      <header className="app-header">
        <a className="brand" href="#workspace" onClick={(event) => { event.preventDefault(); setLayoutMode('3d-only'); }} aria-label="ExtrudeCAD 工作台">
          <span className="brand-mark"><Box size={20} strokeWidth={1.6} /></span>
          <span>Extrude<span className="brand-light">CAD</span></span><small>STUDIO</small>
        </a>
        <div className="header-divider" />
        <span className="document-label">设计工作区</span>
        <nav className="view-switch" aria-label="工作区视图">
          <button aria-pressed={layoutMode === '3d-only'} onClick={() => setLayoutMode('3d-only')}><Box size={14} /><span>模型</span></button>
          <button aria-pressed={layoutMode === '2d-only'} onClick={() => setLayoutMode('2d-only')}><Square size={14} /><span>草图</span></button>
          <button aria-pressed={layoutMode === 'split'} onClick={() => setLayoutMode('split')} title="同时查看二维草图与三维模型"><SplitSquareHorizontal size={14} /><span>双视图</span></button>
        </nav>
        <div className="header-actions">
          <button className="quiet-button command-trigger" title="搜索命令 Ctrl+K" aria-label="打开命令搜索" onClick={() => setCommandOpen(true)}><Search size={15} /><span>命令</span><kbd>Ctrl K</kbd></button>
          <button className="icon-button help-button" title="操作指南" aria-label="打开操作指南" onClick={() => setHelpOpen(true)}><HelpCircle size={17} /></button>
          <FileOpenMenu onOpenProject={handleOpenProject} onImportDxf={() => dxfInputRef.current?.click()} />
          <button className="quiet-button" onClick={handleSaveProject} title="下载可继续编辑的工程文件"><Save size={15} /><span>保存</span></button>
          <button className="primary-button" onClick={() => setIsExportModalOpen(true)}><Download size={15} /><span>导出</span></button>
        </div>
      </header>
      <div className={`workbench-shell ${sidebarOpen ? '' : 'sidebar-collapsed'}`}>
        <aside className="model-sidebar" aria-label="模型浏览器">
          <div className="sidebar-heading"><span>模型浏览器</span><button className="icon-button" aria-label="收起模型浏览器" title="收起模型浏览器" onClick={() => setSidebarOpen(false)}><PanelLeftClose size={15} /></button></div>
          <div className="scene-heading"><span><Layers3 size={14} /> 构件</span><span className="count-badge">{objectQuery ? `${filteredShapes.length} / ` : ''}{shapes.length}</span></div>
          <div className="object-search"><Search size={13} /><input aria-label="搜索构件" placeholder="搜索构件…" value={objectQuery} onChange={(event) => setObjectQuery(event.target.value)} />{objectQuery && <button aria-label="清空构件搜索" onClick={() => setObjectQuery('')}><X size={12} /></button>}</div>
          <div className="object-actions">
            <button title="隐藏所选对象" aria-label="隐藏所选对象" disabled={!selectedIds.length} onClick={() => handleVisibilityCommand('hide-selected')}><EyeOff size={13} />隐藏</button>
            <button title="仅显示所选对象" aria-label="仅显示所选对象" disabled={!selectedIds.length} onClick={() => handleVisibilityCommand('isolate')}><Focus size={13} />隔离</button>
            <button title="显示全部对象" aria-label="显示全部对象" onClick={() => handleVisibilityCommand('show-all')}><Eye size={13} />全部</button>
          </div>
          <div className="object-list">
            {shapes.length === 0 && <div className="empty-tree"><Box size={28} strokeWidth={1} /><p>开始你的设计</p><small>绘制轮廓，或添加一个基本体。</small></div>}
            {shapes.length > 0 && filteredShapes.length === 0 && <p className="empty-search">没有匹配的构件</p>}
            {filteredShapes.map((shape) => <div key={shape.id} className={`object-row ${selectedIds.includes(shape.id) ? 'is-selected' : ''} ${shape.visible ? '' : 'is-hidden'}`}>
              <button className="object-select" aria-pressed={selectedIds.includes(shape.id)} onClick={(event) => handleSelectShape(shape.id, event.ctrlKey || event.metaKey || event.shiftKey)} title={shape.name}>
                <Box size={15} strokeWidth={1.5} /><span>{shape.name}</span>
              </button>
              <button className={`object-visibility object-lock ${shape.locked ? 'is-locked' : ''}`} aria-label={`${shape.locked ? '解锁' : '锁定'} ${shape.name}`} aria-pressed={!!shape.locked} title={shape.locked ? '解锁对象' : '锁定对象，防止编辑与删除'} onClick={() => handleLockObjects([shape.id], !shape.locked)}>{shape.locked ? <LockKeyhole size={12} /> : <UnlockKeyhole size={12} />}</button>
              <button className="object-visibility" aria-label={`${shape.visible ? '隐藏' : '显示'} ${shape.name}`} title={shape.visible ? '隐藏对象' : '显示对象'} onClick={() => handleObjectVisibility(shape.id, !shape.visible)}>{shape.visible ? <Eye size={13} /> : <EyeOff size={13} />}</button>
            </div>)}
          </div>
          <div className="sidebar-add-actions"><button onClick={() => handleAddPrimitive('box')}><Plus size={13} /> 长方体</button><button onClick={() => handleAddPrimitive('cylinder')}><Plus size={13} /> 圆柱体</button></div>
          <div className="tree-note"><MousePointer2 size={13} /><span>Ctrl / Shift + 单击多选</span></div>
          <div className="sidebar-bottom"><button onClick={handleNewEmptyModel}><Plus size={14} /> 新建工程</button><button onClick={handleResetDemo}><RotateCcw size={14} /> 载入结构示例</button></div>
          <div className="sidebar-signature"><span>EXTRUDECAD</span><small>SKETCH · EXTRUDE · CREATE</small></div>
        </aside>
        <main id="workspace" className={`viewport-grid layout-${layoutMode}`}>
          {!sidebarOpen && <button className="reopen-sidebar icon-button" aria-label="展开模型浏览器" title="展开模型浏览器" onClick={() => setSidebarOpen(true)}><PanelLeftOpen size={18} /></button>}
          {showRestoreNotice && <div className="restore-toast" role="status"><Check size={15} /><span>已恢复上次的本地工程</span><button aria-label="关闭恢复提示" onClick={() => setShowRestoreNotice(false)}><X size={14} /></button></div>}
          {selectedIds.length > 1 && <div className="selection-summary" role="status"><Layers3 size={14} /><span>已选 {selectedIds.length} 个对象</span><button onClick={() => setSelectedIds([])} aria-label="清除当前选择">清除 <X size={12} /></button></div>}
          <section aria-label="XY平面二维CAD草图编辑区" className={`viewport-pane sketch-pane ${layoutMode === '3d-only' ? 'pane-hidden' : ''}`}>
          <Cad2DCanvas
            shapes={shapes}
            isActive={layoutMode !== '3d-only'}
            keyboardBlocked={helpOpen || isExportModalOpen || commandOpen || Boolean(dxfFile)}
            fitRequest={fitRequest}
            onBeginGeometryDrag={handleBeginGeometryDrag}
            onCancelGeometryDrag={handleCancelGeometryDrag}
            onEndGeometryDrag={handleEndGeometryDrag}
            onInteractionChange={handleCanvasInteractionChange}
            selectedId={selectedId}
            selectedIds={selectedIds}
            onSelectShape={handleSelectSingleShape}
            onSelectMultipleShapes={setSelectedIds}
            onSelectAll={handleSelectAllShapes}
            onUpdateShape={handleUpdateShape}
            onUpdateMultipleShapes={handleUpdateMultipleShapes}
            onCreateShape={handleCreateShape}
            activeTool={activeTool}
            onChangeTool={setActiveTool}
            defaultZHeight={defaultZHeight}
            snapEnabled={snapEnabled}
            gridStep={gridStep}
            onToggleSnap={() => setSnapEnabled((s) => !s)}
            onChangeGridStep={setGridStep}
            booleanPreview={booleanPreview?.resultShape ?? null}
          />
          </section>
          <section aria-label="三维Z轴拉伸实时预览区" className={`viewport-pane model-pane ${layoutMode === '2d-only' ? 'pane-offscreen' : ''}`}>
          <Cad3DViewport
            shapes={shapes}
            fitRequest={fitRequest}
            selectedIds={selectedIds}
            onSelectShape={handleSelectShape}
            activeView={activeCameraView}
            onChangeView={setActiveCameraView}
            explodedFactor={0}
            wireframeOverlay={wireframeOverlay}
            onToggleWireframe={() => setWireframeOverlay((w) => !w)}
            onRegisterExporter={setExporterApi}
            gridStep={gridStep}
          />
          </section>
<div className="floating-tool-area">      <BottomControlDock
        shapes={shapes}
        selectedId={selectedId}
        selectedIds={selectedIds}
        onSelectShape={handleSelectSingleShape}
        onSelectMultipleShapes={setSelectedIds}
        onSelectAll={handleSelectAllShapes}
        onClearSelection={() => setSelectedIds([])}
        onUpdateShape={handleUpdateShape}
        onUpdateMultipleShapes={handleUpdateMultipleShapes}
        onDeleteShape={handleDeleteShape}
        onDuplicateShape={handleDuplicateShape}
        onAddPrimitive={handleAddPrimitive}
        onCreatePrecisionPrimitive={handleCreatePrecisionPrimitive}
        onTransformSelection={handleTransformSelection}
        panelRequest={panelRequest}
        onBooleanOperation={handleBooleanOperation}
        onBooleanPreview={handleBooleanPreview}
        booleanPreviewActive={booleanPreview !== null}
        onCommitBooleanPreview={handleCommitBooleanPreview}
        onCancelBooleanPreview={handleCancelBooleanPreview}
        onRestoreBoolean={handleRestoreBoolean}
        onMirrorShapes={handleMirrorShapes}
        onRectArray={handleRectArray}
        onPolarArray={handlePolarArray}
        booleanFeedback={booleanFeedback}
        onClearBooleanFeedback={() => setBooleanFeedback(null)}
        onNewEmptyModel={handleNewEmptyModel}
        onResetDemo={handleResetDemo}
        activeTool={activeTool}
        onChangeTool={handleChangeTool}
        defaultZHeight={defaultZHeight}
        onChangeDefaultZHeight={setDefaultZHeight}
        canUndo={canUndo(history)}
        canRedo={canRedo(history)}
        undoCount={history.past.length}
        redoCount={history.future.length}
        onUndo={handleUndo}
        onRedo={handleRedo}
      />
</div>
        </main>
        <Inspector shapes={shapes} selectedIds={selectedIds} onUpdateShape={handleUpdateShape} onUpdateMultipleShapes={handleUpdateMultipleShapes} onDuplicate={() => handleDuplicateShape()} onDelete={() => handleDeleteShape()} />
      </div>
      <footer className="app-statusbar">
        <span className={`save-state ${saveStatus === 'failed' ? 'save-failed' : ''}`}><span className="status-dot" />{saveStatus === 'pending' ? '正在保存…' : saveStatus === 'saved' ? '已自动保存' : '自动保存不可用，请下载工程'}</span>
        <span className="footer-hint">{activeTool === 'measure' ? 'XY 两点测量 · Esc 结束' : layoutMode === '2d-only' ? '拖动绘制 · 滚轮缩放' : '左键旋转 · 右键平移 · 滚轮缩放'}<span>│</span>F 适合视图</span>
        <span className="scene-stats">{visibleCount} / {shapes.length} 构件可见<span className="units-pill">mm</span></span>
      </footer>
      <ExportViewsModal isOpen={isExportModalOpen} onClose={() => setIsExportModalOpen(false)} shapes={shapes} exporterApi={exporterApi} />
      <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} commands={commands} />
      <input ref={dxfInputRef} type="file" accept=".dxf" aria-label="选择 DXF 文件" hidden onChange={handleDxfFile} />
      <DxfImportDialog file={dxfFile} onClose={() => setDxfFile(null)} onImport={handleImportDxf} />
      {helpOpen && <div className="help-backdrop" onClick={() => setHelpOpen(false)} onKeyDown={(event) => { if (event.key === 'Escape') setHelpOpen(false); }}>
        <section className="help-dialog" role="dialog" aria-modal="true" aria-labelledby="help-title" onClick={(event) => event.stopPropagation()}>
          <button className="icon-button help-close" aria-label="关闭操作指南" autoFocus onClick={() => setHelpOpen(false)}><X size={19} /></button>
          <span className="section-eyebrow">QUICK START</span><h2 id="help-title">从草图，到立体。</h2><p className="help-intro">在同一个工作台完成绘制、拉伸与导出。</p>
          <ol className="help-steps"><li><b>01</b><div><strong>绘制或添加形体</strong><p>选择矩形、圆形等工具，在二维画布拖动绘制；也可以一键添加基本体。</p></div></li><li><b>02</b><div><strong>调整尺寸，查看三维</strong><p>选中对象，在右侧属性栏调整高度与尺寸。三维视图可拖动旋转、滚轮缩放。</p></div></li><li><b>03</b><div><strong>保存与导出</strong><p>保存工程可继续编辑；导出支持 STL、OBJ、DXF、SVG 与工程视图。</p></div></li></ol>
          <div className="shortcut-list"><span>命令搜索 <kbd>Ctrl K</kbd></span><span>保存工程 <kbd>Ctrl S</kbd></span><span>撤销 / 重做 <kbd>Ctrl Z / Y</kbd></span><span>复制 <kbd>Ctrl D</kbd></span><span>选择 / 矩形 <kbd>V / R</kbd></span><span>圆 / 直线墙 <kbd>C / L</kbd></span><span>多边形 / 测量 <kbd>P / M</kbd></span><span>适合视图 <kbd>F</kbd></span><span>全选 <kbd>Ctrl A</kbd></span><span>删除未锁对象 <kbd>Delete</kbd></span></div>
          <p className="help-note">适用于 XY 草图沿 Z 轴拉伸的轻量建模。工程保存在当前浏览器中；换设备或重要修改后，请下载工程文件。</p><button className="primary-button help-done" onClick={() => setHelpOpen(false)}>开始建模 <ChevronRight size={16} /></button>
        </section>
      </div>}
    </div>
  );
}
