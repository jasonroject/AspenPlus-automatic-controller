# Validation — 2026-11-17

## Ego interaction revision

- Consulted Gemini in Ego for interaction review. Kept the existing charcoal visual system; implemented concrete selection, preview, input and panel improvements.
- Reproduced before editing: Ctrl-click on the 3D sleeve replaced the selected base; Boolean preview remained in `3d-only` while its result existed only in the hidden 2D canvas.
- Verified in Ego: Ctrl/Shift add/toggle selection, modifier-click on blank preserves selection, ordinary blank clears it, all selected objects highlight, and orbit dragging does not change selection.
- Boolean preview now opens the 2D canvas and collapses the command panel. Preview does not change the six-object scene. Editing the base width from 112 to 120 invalidated the preview; applying a fresh preview produced seven objects with two hidden operands, and one undo restored six visible originals.
- Bottom numeric fields accept an empty draft without changing geometry. Committing width 125 and undoing once restored 112. A mixed-height selection (8 and 32) was unified to 8 by entering the first object's existing value; one undo restored the sleeve to 32.
- Found and repaired the 800 ms autosave debounce gap on page exit. Immediate reload after setting width 120 retained 120. Restored the final model to width 112.
- Reviewed 1366 × 768 and 1130 × 650 layouts. At 1130 px the Boolean panel was 660 px inside a 700 px canvas. At 1000 px it shrank to 546 px inside a 570 px canvas, without horizontal overflow.
- Downloaded and parsed the actual project JSON (six objects, base width 112 mm) and STL (3,456 vertices; bounds X [-56, 56], Y [-42, 42], Z [0, 40] mm).
- TypeScript check and production/standalone build passed. All 21 existing geometry, serialization and storage tests passed. Final artifact is `deliverables/ExtrudeCAD_Studio.html`.
- Browser evidence and checks: `../outputs/ego-cad-20261117/`. Testing used the exact standalone artifact served over localhost in Ego; direct `file://` opening and mobile editing were not tested in this pass.

## Charcoal theme revision

- Applied neutral charcoal surfaces across shell, inspector, tool drawers, dialogs, 2D and 3D viewports. Blue remains the selection accent; original model color data is preserved.
- Browser-reviewed the 3D workspace, 2D dimensions/grid and export dialog. Engineering-sheet preview stays on light paper and restores the dark scene after rendering.
- TypeScript check passed; final browser console showed no warnings or errors. Geometry and editing logic were not changed.

## Precision Light revision

- Consulted Gemini in three rounds: design hierarchy, technical boundaries, and acceptance criteria. Retained explicit user control over custom colors and split views.
- Rebuilt the shell with a 48 px graphite header, 220 px object tree, 260 px inspector and contextual floating tools. Fixed grid min-content overflow that pushed the header outside the viewport.
- Tested Chrome at 1366 × 768 and the original desktop viewport. Verified 2D, 3D, split layouts and the compact camera selector for narrow panes.
- Changed base width from 112 to 120 mm in the inspector. The 2D label and export summary updated. Downloaded the actual STL and parsed 3,456 vertices: bounds X [-60,60], Y [-42,42], Z [0,40] mm. Undo/redo/undo restored 112 mm.
- Verified engineering-sheet preview rendered with all standard views; browser error/warning log was empty after the final checks.
- Added true orthographic cameras for isometric and standard engineering views, with correct camera/control rebinding and fit padding for the floating tools.
- Smooth preview normals preserve 30-degree creases. Actual STL/OBJ topology is unchanged. Demo is six independent solids with two aligned real through-holes; it does not imply assembly constraints or bolt mounting holes.
- Re-ran all 21 geometry/serialization/storage tests successfully; final TypeScript check passed.

## Initial implementation validation

- TypeScript type check passed.
- 21 automated geometry, serialization and storage tests passed. Regression coverage includes watertight hollow STL/OBJ, bevel geometry, Z offsets, SVG bounds, empty projects, corrupt imports and unavailable local storage.
- Chrome desktop: loaded the redesigned workbench; added a cylinder; changed extrusion height from 30 to 45 mm and confirmed volume/height display changed.
- Drew a rectangle by dragging on the actual 2D canvas; confirmed a sixth shape and corresponding dimensions appeared.
- Undo removed the new shape and redo restored it.
- Saved the six-shape project; verified a 6,910-byte `.extrudecad.json` download on disk.
- STL export showed success feedback; engineering-sheet tab rendered its multi-view preview.
- Built `deliverables/ExtrudeCAD_Studio.html` (about 1 MB), with JavaScript/CSS/Three.js embedded and no remote fonts or application assets. Served this exact artifact over localhost and confirmed both 2D and 3D workspaces rendered.
- Direct `file://` navigation could not be tested through the browser automation interface because its URL policy allows only HTTP(S). No browser security settings were changed. The HTML has no external application asset requests and is intended for local opening.

The inherited editor remains a 2D-profile/Z-extrusion tool, not an unrestricted solid-modeling kernel. Mobile CSS is provided; this pass verified desktop browser interactions.
