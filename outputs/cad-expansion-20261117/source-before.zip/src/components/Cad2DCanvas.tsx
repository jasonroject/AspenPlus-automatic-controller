import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  CadShape,
  Point2D,
  SmartSnapGuide,
  snapToGrid,
  findGeometrySnap,
  GeometrySnapResult,
  computeBounds2D,
  computeShapeDimensions,
  findClosestShapeEdge,
  computeMoveSnapGuides,
  computePointSnapGuides,
  computeBoxSelectedShapeIds,
  createRectanglePoints,
  createTrianglePoints,
  createRegularPolygonPoints,
  createLineWallPoints,
  resizeShapeEdge2D,
  resizeLineWall2D,
  resizeCircleDiameter2D,
} from '../utils/cadEngine';
import {
  Grid,
  Maximize2,
  Check,
  X,
  Ruler,
  Magnet,
  HelpCircle,
  BoxSelect,
} from 'lucide-react';

export type DrawTool2D =
  | 'select'
  | 'line'
  | 'rect'
  | 'triangle'
  | 'circle'
  | 'polyline';

type ResizeEdgeSide = 'left' | 'right' | 'top' | 'bottom';

interface Cad2DCanvasProps {
  shapes: CadShape[];
  selectedId: string | null;
  selectedIds?: string[];
  onSelectShape: (id: string | null) => void;
  onSelectMultipleShapes?: (ids: string[]) => void;
  onSelectAll?: () => void;
  onUpdateShape: (updated: CadShape, transient?: boolean) => void;
  onUpdateMultipleShapes?: (nextShapes: CadShape[], transient?: boolean) => void;
  onCreateShape: (newShape: CadShape) => void;
  /** Boolean preview outline (dashed, not committed) */
  booleanPreview?: CadShape | null;
  activeTool: DrawTool2D;
  onChangeTool: (tool: DrawTool2D) => void;
  defaultZHeight: number;
  snapEnabled: boolean;
  gridStep: number;
  onToggleSnap: () => void;
  onChangeGridStep: (step: number) => void;
}

export const Cad2DCanvas: React.FC<Cad2DCanvasProps> = ({
  shapes,
  selectedId,
  selectedIds: propSelectedIds,
  onSelectShape,
  onSelectMultipleShapes,
  onSelectAll,
  onUpdateShape,
  onUpdateMultipleShapes,
  onCreateShape,
  booleanPreview = null,
  activeTool,
  onChangeTool,
  defaultZHeight,
  snapEnabled,
  gridStep,
  onToggleSnap,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const dragHistoryPushedRef = useRef<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      setCanvasSize((previous) =>
        previous.width === width && previous.height === height
          ? previous
          : { width, height },
      );
    });
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);

  const selectedIds = useMemo(
    () => propSelectedIds ?? (selectedId ? [selectedId] : []),
    [propSelectedIds, selectedId],
  );
  const selectedIdSet = useMemo(() => new Set(selectedIds), [selectedIds]);

  const [zoom, setZoom] = useState<number>(2.8);
  const [pan, setPan] = useState<Point2D>({ x: 0, y: 0 });
  const [cursorMm, setCursorMm] = useState<Point2D>({ x: 0, y: 0 });

  // CAD Dimension Annotation ('adaptive' = 隐性自适应, 'all' = 全显, 'hidden' = 关), Smart Snap & Mouse Guide states
  const [annotationMode, setAnnotationMode] = useState<'adaptive' | 'all' | 'hidden'>('adaptive');
  const showDimensions = annotationMode !== 'hidden';
  const [smartGuidesEnabled, setSmartGuidesEnabled] = useState<boolean>(true);
  const [showMouseGuide, setShowMouseGuide] = useState<boolean>(false);
  const [showEdgeListHud, setShowEdgeListHud] = useState<boolean>(false);
  const [selectedEdgeIndex, setSelectedEdgeIndex] = useState<number | null>(null);
  const [hoveredTarget, setHoveredTarget] = useState<{
    shapeId: string | null;
    edgeIndex: number | null;
  }>({ shapeId: null, edgeIndex: null });
  const [activeSnapGuides, setActiveSnapGuides] = useState<SmartSnapGuide[]>([]);
  const [selectionModeLabel, setSelectionModeLabel] = useState<string>(
    '选整体图形 (点击内部选整体 / 空白拖拽框选)',
  );

  // Interactive states for drawing, moving, edge-pushing, vertex-resizing & marquee box selection
  const [draftPoints, setDraftPoints] = useState<Point2D[]>([]);
  const [dragStartMm, setDragStartMm] = useState<Point2D | null>(null);
  // 几何捕捉（端点/中点/圆心）与拖画精确尺寸输入状态
  const [geometrySnap, setGeometrySnap] = useState<GeometrySnapResult | null>(null);
  const [sizeInput, setSizeInput] = useState<string>('');
  const [draggingVertexIdx, setDraggingVertexIdx] = useState<number | null>(null);
  const [draggingHoleVertexIdx, setDraggingHoleVertexIdx] = useState<number | null>(null);
  const [draggingSingleEdge, setDraggingSingleEdge] = useState<{
    shapeId: string;
    edgeIndex: number;
    startMm: Point2D;
    origPoints: Point2D[];
  } | null>(null);
  const [draggingResizeEdge, setDraggingResizeEdge] = useState<{
    shapeId: string;
    side: ResizeEdgeSide;
    origPoints: Point2D[];
    origHolePoints?: Point2D[];
    origBounds: ReturnType<typeof computeBounds2D>;
  } | null>(null);
  const [draggingWholeShape, setDraggingWholeShape] = useState<{
    primaryShapeId: string;
    movingIds: string[];
    startMm: Point2D;
    origShapesMap: Record<
      string,
      { points: Point2D[]; holePoints?: Point2D[] }
    >;
  } | null>(null);
  const [marqueeBox, setMarqueeBox] = useState<{
    startMm: Point2D;
    currentMm: Point2D;
    additive: boolean;
  } | null>(null);
  const [isPanning, setIsPanning] = useState<{
    startX: number;
    startY: number;
    origPan: Point2D;
  } | null>(null);

  const commitSelectedIds = useCallback(
    (ids: string[]) => {
      if (onSelectMultipleShapes) {
        onSelectMultipleShapes(ids);
      } else {
        onSelectShape(ids[0] ?? null);
      }
    },
    [onSelectMultipleShapes, onSelectShape],
  );

  // Clear draft state when switching tools
  useEffect(() => {
    setDraftPoints([]);
    setDragStartMm(null);
    setActiveSnapGuides([]);
    setMarqueeBox(null);
    setGeometrySnap(null);
    setSizeInput('');
  }, [activeTool]);

  // Reset highlighted edge when primary selected shape changes
  useEffect(() => {
    setSelectedEdgeIndex(null);
  }, [selectedId]);

  const selectedShape = useMemo(
    () => shapes.find((s) => s.id === selectedId && s.visible) ?? null,
    [shapes, selectedId],
  );

  const selectedDimensions = useMemo(
    () => (selectedShape ? computeShapeDimensions(selectedShape) : null),
    [selectedShape],
  );

  // Live preview of shapes hit by active marquee box
  const marqueePreview = useMemo(() => {
    if (!marqueeBox) return null;
    return computeBoxSelectedShapeIds(
      marqueeBox.startMm,
      marqueeBox.currentMm,
      shapes,
    );
  }, [marqueeBox, shapes]);

  // Only display smart alignment guides while actively dragging, resizing, or drawing
  const displayedSnapGuides = useMemo(() => {
    if (!smartGuidesEnabled) return [];
    return activeSnapGuides;
  }, [smartGuidesEnabled, activeSnapGuides]);

  const screenToMm = useCallback(
    (px: number, py: number, width: number, height: number, applySnap = true): Point2D => {
      const cx = width / 2 + pan.x;
      const cy = height / 2 + pan.y;
      const rawX = (px - cx) / zoom;
      const rawY = -(py - cy) / zoom;
      return {
        x: snapToGrid(rawX, gridStep, applySnap && snapEnabled),
        y: snapToGrid(rawY, gridStep, applySnap && snapEnabled),
      };
    },
    [pan, zoom, gridStep, snapEnabled],
  );

  const mmToScreen = useCallback(
    (x: number, y: number, width: number, height: number): Point2D => {
      const cx = width / 2 + pan.x;
      const cy = height / 2 + pan.y;
      return {
        x: cx + x * zoom,
        y: cy - y * zoom,
      };
    },
    [pan, zoom],
  );

  const isPointInPolygon = (pt: Point2D, poly: Point2D[]): boolean => {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const xi = poly[i].x,
        yi = poly[i].y;
      const xj = poly[j].x,
        yj = poly[j].y;
      const intersect =
        yi > pt.y !== yj > pt.y &&
        pt.x < ((xj - xi) * (pt.y - yi)) / (yj - yi + 1e-9) + xi;
      if (intersect) inside = !inside;
    }
    return inside;
  };

  // Commit a newly drawn polyline polygon
  const commitPolyline = useCallback(() => {
    if (draftPoints.length < 2) return;
    const pts =
      draftPoints.length === 2
        ? createLineWallPoints(draftPoints[0], draftPoints[1], 8)
        : [...draftPoints];
    const newShape: CadShape = {
      id: `cad-poly-${Date.now()}`,
      name:
        draftPoints.length === 2
          ? `直线墙 #${shapes.length + 1}`
          : `折线图形 #${shapes.length + 1}`,
      type: draftPoints.length === 2 ? 'line' : 'polyline',
      points: pts,
      zHeight: defaultZHeight,
      zOffset: 0,
      bevel: 0.6,
      color: '#A5ADB8',
      materialPreset: 'aluminum',
      visible: true,
    };
    onCreateShape(newShape);
    setDraftPoints([]);
    setActiveSnapGuides([]);
    onChangeTool('select');
  }, [draftPoints, shapes.length, defaultZHeight, onCreateShape, onChangeTool]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setDraftPoints([]);
        setDragStartMm(null);
        setSelectedEdgeIndex(null);
        setActiveSnapGuides([]);
        setMarqueeBox(null);
        onChangeTool('select');
      } else if (e.key === 'Enter' && activeTool === 'polyline' && draftPoints.length >= 2) {
        commitPolyline();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTool, draftPoints.length, commitPolyline, onChangeTool]);

  // Draw the 2D CAD Blueprint Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = rect.width;
    const height = rect.height;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.save();
    ctx.scale(dpr, dpr);

    const adaptiveFontPx = 11;

    // Helper: Crisp CAD Halo Text (no bulky opaque background rectangle)
    const drawHaloText = (
      text: string,
      x: number,
      y: number,
      fillColor: string,
      fontSizePx = adaptiveFontPx,
      fontWeight = 600,
      haloWidth = 3.2,
    ) => {
      ctx.save();
      ctx.font = `${fontWeight} ${fontSizePx}px "JetBrains Mono", "Noto Sans SC", monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      ctx.miterLimit = 2;
      ctx.lineWidth = haloWidth;
      ctx.strokeStyle = 'rgba(27, 29, 33, 0.97)';
      ctx.strokeText(text, x, y);
      ctx.fillStyle = fillColor;
      ctx.fillText(text, x, y);
      ctx.restore();
    };

    // Helper: Draw adaptive CAD-style Linear Dimension Annotation (box-free halo text)
    const drawCadLinearDimension = (
      p1Mm: Point2D,
      p2Mm: Point2D,
      outwardNormalMm: Point2D,
      offsetPx: number,
      label: string,
      color = 'rgba(76, 154, 255, 0.78)',
      isHighlighted = false,
    ) => {
      const s1 = mmToScreen(p1Mm.x, p1Mm.y, width, height);
      const s2 = mmToScreen(p2Mm.x, p2Mm.y, width, height);
      const segPx = Math.hypot(s2.x - s1.x, s2.y - s1.y);
      if (!isHighlighted && segPx < 28) return;
      if (segPx < 10) return;

      const fontSize = isHighlighted
        ? Math.max(9.5, adaptiveFontPx + 0.5)
        : Math.max(8, adaptiveFontPx - 0.5);
      ctx.font = `${isHighlighted ? 700 : 500} ${fontSize}px "JetBrains Mono", "Noto Sans SC", monospace`;
      const textW = ctx.measureText(label).width;
      // Adaptive anti-crowding: skip non-highlighted dimension if segment is narrower than text
      if (!isHighlighted && segPx < textW * 0.78) return;

      const nLen = Math.hypot(outwardNormalMm.x, outwardNormalMm.y) || 1;
      const nx = outwardNormalMm.x / nLen;
      const ny = -outwardNormalMm.y / nLen;

      const effectiveOffset = isHighlighted
        ? Math.max(14, offsetPx * 0.78)
        : Math.max(10, Math.min(15, offsetPx * 0.62));
      const gapPx = 3;
      const extOvershootPx = 4;
      const d1 = { x: s1.x + nx * effectiveOffset, y: s1.y + ny * effectiveOffset };
      const d2 = { x: s2.x + nx * effectiveOffset, y: s2.y + ny * effectiveOffset };

      ctx.save();
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = isHighlighted ? 1.35 : 0.85;

      // 1. Subtle extension lines
      ctx.beginPath();
      ctx.moveTo(s1.x + nx * gapPx, s1.y + ny * gapPx);
      ctx.lineTo(
        s1.x + nx * (effectiveOffset + extOvershootPx),
        s1.y + ny * (effectiveOffset + extOvershootPx),
      );
      ctx.moveTo(s2.x + nx * gapPx, s2.y + ny * gapPx);
      ctx.lineTo(
        s2.x + nx * (effectiveOffset + extOvershootPx),
        s2.y + ny * (effectiveOffset + extOvershootPx),
      );
      ctx.stroke();

      // 2. Dimension line
      ctx.beginPath();
      ctx.moveTo(d1.x, d1.y);
      ctx.lineTo(d2.x, d2.y);
      ctx.stroke();

      // 3. Compact CAD 45° architectural ticks
      const ux = (d2.x - d1.x) / segPx;
      const uy = (d2.y - d1.y) / segPx;
      const px = -uy;
      const py = ux;
      const tickSize = isHighlighted ? 3.2 : 2.4;
      ctx.beginPath();
      ctx.moveTo(d1.x - (ux + px) * tickSize, d1.y - (uy + py) * tickSize);
      ctx.lineTo(d1.x + (ux + px) * tickSize, d1.y + (uy + py) * tickSize);
      ctx.moveTo(d2.x - (ux + px) * tickSize, d2.y - (uy + py) * tickSize);
      ctx.lineTo(d2.x + (ux + px) * tickSize, d2.y + (uy + py) * tickSize);
      ctx.stroke();
      ctx.restore();

      // 4. Adaptive Halo Text (zero opaque border box)
      const midX = (d1.x + d2.x) / 2;
      const midY = (d1.y + d2.y) / 2;
      const textOffset = isHighlighted ? 7 : 5;
      const labelX = midX + nx * (Math.abs(nx) > 0.4 ? textW * 0.35 + 4 : textOffset * nx);
      const labelY = midY + ny * textOffset;

      drawHaloText(
        label,
        labelX,
        labelY,
        isHighlighted ? '#4c9aff' : '#d0d7e1',
        fontSize,
        isHighlighted ? 700 : 500,
        3.5,
      );
    };

    // 1. Background fill
    ctx.fillStyle = '#1b1d21';
    ctx.fillRect(0, 0, width, height);

    const cx = width / 2 + pan.x;
    const cy = height / 2 + pan.y;

    // 2. Grid lines
    const minorStep = Math.max(gridStep, Math.pow(2, Math.ceil(Math.log2(18 / zoom / gridStep))) * gridStep);
    const majorStep = minorStep * 5;

    const minXMm = Math.floor(-cx / zoom / minorStep) * minorStep;
    const maxXMm = Math.ceil((width - cx) / zoom / minorStep) * minorStep;
    const minYMm = Math.floor(-(height - cy) / zoom / minorStep) * minorStep;
    const maxYMm = Math.ceil(cy / zoom / minorStep) * minorStep;

    ctx.lineWidth = 1;
    for (let x = minXMm; x <= maxXMm; x += minorStep) {
      const sx = cx + x * zoom;
      const isMajor = Math.abs(x % majorStep) < 0.001;
      ctx.strokeStyle = isMajor ? '#30353d' : '#23282f';
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
      ctx.stroke();
    }

    for (let y = minYMm; y <= maxYMm; y += minorStep) {
      const sy = cy - y * zoom;
      const isMajor = Math.abs(y % majorStep) < 0.001;
      ctx.strokeStyle = isMajor ? '#30353d' : '#23282f';
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
      ctx.stroke();
    }

    // 3. Coordinate Origin Axes (+X Red, +Y Green)
    ctx.lineWidth = 1;
    ctx.strokeStyle = '#434b58';
    ctx.beginPath();
    ctx.moveTo(0, cy);
    ctx.lineTo(width, cy);
    ctx.stroke();

    ctx.strokeStyle = '#434b58';
    ctx.beginPath();
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, height);
    ctx.stroke();

    ctx.fillStyle = '#a3abb8';
    ctx.font = '500 10px "JetBrains Mono", "Noto Sans SC", monospace';
    ctx.strokeStyle = '#6f7987';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx - 4, cy);
    ctx.lineTo(cx + 4, cy);
    ctx.moveTo(cx, cy - 4);
    ctx.lineTo(cx, cy + 4);
    ctx.stroke();
    ctx.fillStyle = '#a3abb8';
    ctx.fillText('+X 轴 (mm)', width - 64, cy - 6);
    ctx.fillStyle = '#a3abb8';
    ctx.fillText('+Y 轴 (mm)', cx + 6, 16);

    // 3b. Render Dynamic Smart Snap Alignment Guides
    const isActivelyInteracting =
      draggingWholeShape !== null ||
      draggingVertexIdx !== null ||
      draggingSingleEdge !== null ||
      draggingHoleVertexIdx !== null ||
      draggingResizeEdge !== null ||
      dragStartMm !== null;

    if (smartGuidesEnabled && displayedSnapGuides.length > 0) {
      displayedSnapGuides.forEach((guide) => {
        const sStart = mmToScreen(guide.startMm.x, guide.startMm.y, width, height);
        const sEnd = mmToScreen(guide.endMm.x, guide.endMm.y, width, height);
        const sAct = mmToScreen(guide.activeAnchorPt.x, guide.activeAnchorPt.y, width, height);
        const sRef = mmToScreen(guide.targetAnchorPt.x, guide.targetAnchorPt.y, width, height);

        const guideColor = guide.axis === 'x' ? '#4c9aff' : '#4c9aff';
        const subtleLaserColor =
          guide.axis === 'x' ? 'rgba(76, 154, 255, 0.18)' : 'rgba(76, 154, 255, 0.18)';

        ctx.save();
        ctx.strokeStyle = subtleLaserColor;
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (guide.axis === 'x') {
          ctx.moveTo(sStart.x, 0);
          ctx.lineTo(sStart.x, height);
        } else {
          ctx.moveTo(0, sStart.y);
          ctx.lineTo(width, sStart.y);
        }
        ctx.stroke();

        ctx.strokeStyle = guideColor;
        ctx.lineWidth = isActivelyInteracting ? 1.8 : 1.3;
        ctx.setLineDash([5, 3]);
        ctx.beginPath();
        ctx.moveTo(sStart.x, sStart.y);
        ctx.lineTo(sEnd.x, sEnd.y);
        ctx.stroke();
        ctx.setLineDash([]);

        const drawDiamond = (x: number, y: number) => {
          const r = 4.2;
          ctx.fillStyle = '#272a2f';
          ctx.strokeStyle = guideColor;
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(x, y - r);
          ctx.lineTo(x + r, y);
          ctx.lineTo(x, y + r);
          ctx.lineTo(x - r, y);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        };
        drawDiamond(sAct.x, sAct.y);
        drawDiamond(sRef.x, sRef.y);

        const badgeX = guide.axis === 'x' ? sAct.x : (sAct.x + sRef.x) / 2;
        const badgeY = guide.axis === 'x' ? (sAct.y + sRef.y) / 2 : sAct.y - 14;

        const shortBadge =
          guide.axis === 'x'
            ? `对齐 X=${guide.valueMm}mm (${guide.activeAnchorLabel})`
            : `对齐 Y=${guide.valueMm}mm (${guide.activeAnchorLabel})`;
        ctx.font = '600 9.5px "JetBrains Mono", "Noto Sans SC", monospace';
        const tw = ctx.measureText(shortBadge).width;
        const pw = tw + 10;
        const ph = 16;

        ctx.fillStyle = 'rgba(39, 42, 47, 0.97)';
        ctx.fillRect(badgeX - pw / 2, badgeY - ph / 2, pw, ph);
        ctx.strokeStyle = guideColor;
        ctx.lineWidth = 1.2;
        ctx.strokeRect(badgeX - pw / 2, badgeY - ph / 2, pw, ph);
        ctx.fillStyle = guide.axis === 'x' ? '#4c9aff' : '#4c9aff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(shortBadge, badgeX, badgeY);

        ctx.restore();
      });
    }

    // 4. Render all visible CAD shapes on XY plane
    const marqueeHitSet = new Set(marqueePreview?.selectedIds ?? []);

    shapes.forEach((shape) => {
      if (!shape.visible || shape.points.length < 2) return;
      const isSelected = selectedIdSet.has(shape.id);
      const isPrimarySelected = shape.id === selectedId;
      const isMarqueeHit = marqueeHitSet.has(shape.id);

      ctx.save();
      ctx.beginPath();
      shape.points.forEach((pt, idx) => {
        const s = mmToScreen(pt.x, pt.y, width, height);
        if (idx === 0) ctx.moveTo(s.x, s.y);
        else ctx.lineTo(s.x, s.y);
      });
      ctx.closePath();

      if (shape.holePoints && shape.holePoints.length >= 3) {
        shape.holePoints.forEach((pt, idx) => {
          const s = mmToScreen(pt.x, pt.y, width, height);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
      }

      ctx.fillStyle = isSelected || isMarqueeHit ? 'rgba(76, 154, 255, 0.08)' : 'rgba(189, 199, 212, 0.035)';
      ctx.fill('evenodd');

      ctx.lineWidth = isSelected || isMarqueeHit ? 1.6 : 1.15;
      ctx.strokeStyle = isMarqueeHit
        ? '#4c9aff'
        : isSelected
          ? '#4c9aff'
          : '#bdc7d4';
      ctx.stroke();

      // Geometry dimensions are placed outside the selected outline.
      const bounds = computeBounds2D(shape.points);
      const screenW = bounds.widthX * zoom;
      const screenH = bounds.depthY * zoom;
      const isHoveredShape = hoveredTarget.shapeId === shape.id;
      const hoveredEdgeForShape = isHoveredShape ? hoveredTarget.edgeIndex : null;

      // 4a. Implicit hover edge length on unselected shapes
      if (
        isPrimarySelected &&
        isHoveredShape &&
        hoveredEdgeForShape !== null &&
        showDimensions
      ) {
        const hoverDim = computeShapeDimensions(shape);
        const hEdge = hoverDim.edges[hoveredEdgeForShape];
        if (hEdge) {
          const s1 = mmToScreen(hEdge.start.x, hEdge.start.y, width, height);
          const s2 = mmToScreen(hEdge.end.x, hEdge.end.y, width, height);
          ctx.save();
          ctx.strokeStyle = 'rgba(76, 154, 255, 0.85)';
          ctx.lineWidth = 2.6;
          ctx.beginPath();
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(s2.x, s2.y);
          ctx.stroke();
          ctx.restore();

          drawCadLinearDimension(
            hEdge.start,
            hEdge.end,
            hEdge.outwardNormal,
            16,
            `${hEdge.lengthMm}mm`,
            '#4c9aff',
            true,
          );
        }
      }

      // 4b. Adaptive & Implicit CAD Dimension Annotations for the primary selected shape
      if (isPrimarySelected && selectedIds.length === 1 && showDimensions) {
        const dim = computeShapeDimensions(shape);
        const activeEdgeIdx =
          hoveredEdgeForShape !== null ? hoveredEdgeForShape : selectedEdgeIndex;

        if (dim.isLineFeature && dim.lineStart && dim.lineEnd) {
          const ls = mmToScreen(dim.lineStart.x, dim.lineStart.y, width, height);
          const le = mmToScreen(dim.lineEnd.x, dim.lineEnd.y, width, height);
          ctx.save();
          ctx.strokeStyle = 'rgba(76, 154, 255, 0.75)';
          ctx.lineWidth = 1.2;
          ctx.setLineDash([4, 3]);
          ctx.beginPath();
          ctx.moveTo(ls.x, ls.y);
          ctx.lineTo(le.x, le.y);
          ctx.stroke();
          ctx.restore();

          const dx = dim.lineEnd.x - dim.lineStart.x;
          const dy = dim.lineEnd.y - dim.lineStart.y;
          const len = Math.hypot(dx, dy) || 1;
          let normalMm = { x: -dy / len, y: dx / len };
          if (normalMm.y < 0) {
            normalMm = { x: -normalMm.x, y: -normalMm.y };
          }
          drawCadLinearDimension(
            dim.lineStart,
            dim.lineEnd,
            normalMm,
            18,
            `L=${dim.primaryLengthMm}mm`,
            '#4c9aff',
            true,
          );
        } else if (shape.type === 'circle' && dim.radiusMm && dim.diameterMm) {
          const cMm = dim.centroid;
          const rMm = dim.radiusMm;
          const placeOnTop = cMm.y >= 0;
          if (screenW >= 36 || isHoveredShape || annotationMode === 'all') {
            drawCadLinearDimension(
              { x: cMm.x - rMm, y: placeOnTop ? cMm.y + rMm : cMm.y - rMm },
              { x: cMm.x + rMm, y: placeOnTop ? cMm.y + rMm : cMm.y - rMm },
              { x: 0, y: placeOnTop ? 1 : -1 },
              14,
              `Ø${dim.diameterMm}mm`,
              'rgba(76, 154, 255, 0.85)',
              isHoveredShape,
            );
          }
        } else {
          // Polygon / Rect / Triangle / Boolean shape:
          // 1) In 'adaptive' mode, show subtle overall W & D only when shape is large enough on screen
          const placeTop = bounds.centroid.y >= 0;
          const placeRight = bounds.centroid.x >= 0;
          const showOverallBounds =
            annotationMode === 'all' || (screenW >= 48 && screenH >= 48);

          if (showOverallBounds && (shape.type === 'rect' || annotationMode === 'adaptive')) {
            const hStart = { x: bounds.minX, y: placeTop ? bounds.maxY : bounds.minY };
            const hEnd = { x: bounds.maxX, y: placeTop ? bounds.maxY : bounds.minY };
            const vStart = { x: placeRight ? bounds.maxX : bounds.minX, y: bounds.minY };
            const vEnd = { x: placeRight ? bounds.maxX : bounds.minX, y: bounds.maxY };

            drawCadLinearDimension(
              hStart,
              hEnd,
              { x: 0, y: placeTop ? 1 : -1 },
              14,
              `宽${bounds.widthX.toFixed(0)}`,
              'rgba(76, 154, 255, 0.68)',
              false,
            );
            drawCadLinearDimension(
              vStart,
              vEnd,
              { x: placeRight ? 1 : -1, y: 0 },
              14,
              `深${bounds.depthY.toFixed(0)}`,
              'rgba(76, 154, 255, 0.68)',
              false,
            );
          }

          // 2) Individual edges:
          // - In 'adaptive' mode (隐性注释): ONLY show the edge that is currently hovered or clicked!
          // - In 'all' mode (全显): show all edges that fit on screen.
          if (annotationMode === 'all' && shape.type !== 'rect') {
            dim.edges.forEach((edge) => {
              const isEdgeActive = activeEdgeIdx === edge.edgeIndex;
              if (isEdgeActive) {
                const s1 = mmToScreen(edge.start.x, edge.start.y, width, height);
                const s2 = mmToScreen(edge.end.x, edge.end.y, width, height);
                ctx.save();
                ctx.strokeStyle = '#4c9aff';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(s1.x, s1.y);
                ctx.lineTo(s2.x, s2.y);
                ctx.stroke();
                ctx.restore();
              }
              drawCadLinearDimension(
                edge.start,
                edge.end,
                edge.outwardNormal,
                isEdgeActive ? 20 : 14,
                isEdgeActive
                  ? `边${edge.edgeIndex + 1}:${edge.lengthMm}mm`
                  : `${edge.lengthMm}`,
                isEdgeActive ? '#4c9aff' : 'rgba(76, 154, 255, 0.72)',
                isEdgeActive,
              );
            });
          } else if (activeEdgeIdx !== null && dim.edges[activeEdgeIdx]) {
            const selEdge = dim.edges[activeEdgeIdx];
            const s1 = mmToScreen(selEdge.start.x, selEdge.start.y, width, height);
            const s2 = mmToScreen(selEdge.end.x, selEdge.end.y, width, height);
            ctx.save();
            ctx.strokeStyle = '#4c9aff';
            ctx.lineWidth = 3.2;
            ctx.beginPath();
            ctx.moveTo(s1.x, s1.y);
            ctx.lineTo(s2.x, s2.y);
            ctx.stroke();
            ctx.restore();

            drawCadLinearDimension(
              selEdge.start,
              selEdge.end,
              selEdge.outwardNormal,
              20,
              `边${activeEdgeIdx + 1}: ${selEdge.lengthMm}mm (∠${selEdge.angleDeg}°)`,
              '#4c9aff',
              true,
            );
          }
        }
      }

      if (isPrimarySelected && selectedIds.length === 1) {
        // Vertex handles (■ 方形顶点控点)
        if (shape.points.length <= 16) {
          shape.points.forEach((pt, idx) => {
            const s = mmToScreen(pt.x, pt.y, width, height);
            ctx.fillStyle = draggingVertexIdx === idx ? '#4c9aff' : '#272a2f';
            ctx.strokeStyle = '#4c9aff';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.rect(s.x - 4.5, s.y - 4.5, 9, 9);
            ctx.fill();
            ctx.stroke();
          });
        }

        // Bounding-Box Midpoint Resize Handles (● 圆形缩放控点)
        if (!shape.locked && bounds.widthX >= 4 && bounds.depthY >= 4) {
          const edgeHandles: { side: ResizeEdgeSide; pt: Point2D }[] = [
            { side: 'left', pt: { x: bounds.minX, y: bounds.centroid.y } },
            { side: 'right', pt: { x: bounds.maxX, y: bounds.centroid.y } },
            { side: 'top', pt: { x: bounds.centroid.x, y: bounds.maxY } },
            { side: 'bottom', pt: { x: bounds.centroid.x, y: bounds.minY } },
          ];
          edgeHandles.forEach((h) => {
            const hs = mmToScreen(h.pt.x, h.pt.y, width, height);
            const isDraggingThis = draggingResizeEdge?.side === h.side;
            ctx.fillStyle = isDraggingThis ? '#4c9aff' : '#4c9aff';
            ctx.strokeStyle = '#272a2f';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(hs.x, hs.y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          });
        }
      }

      ctx.restore();
    });

    // 4c. Render Group Bounding Box when multiple shapes are batch-selected
    if (selectedIds.length > 1) {
      const batchShapes = shapes.filter((s) => selectedIdSet.has(s.id) && s.visible);
      const allPts = batchShapes.flatMap((s) => s.points);
      if (allPts.length > 0) {
        const groupBounds = computeBounds2D(allPts);
        const totalArea = batchShapes.reduce(
          (acc, s) => acc + computeShapeDimensions(s).areaMm2,
          0,
        );
        const tl = mmToScreen(groupBounds.minX, groupBounds.maxY, width, height);
        const br = mmToScreen(groupBounds.maxX, groupBounds.minY, width, height);

        ctx.save();
        ctx.strokeStyle = '#4c9aff';
        ctx.lineWidth = 1.6;
        ctx.setLineDash([6, 4]);
        ctx.strokeRect(
          tl.x - 8,
          tl.y - 8,
          br.x - tl.x + 16,
          br.y - tl.y + 16,
        );
        ctx.setLineDash([]);

        const groupLabel = `已批量选中 ${batchShapes.length} 个图形 · 总面积 S=${totalArea.toFixed(0)}mm² (按住任一图形可整体移动)`;
        ctx.font = '600 10.5px "JetBrains Mono", "Noto Sans SC", monospace';
        const gw = ctx.measureText(groupLabel).width + 14;
        const gx = (tl.x + br.x) / 2;
        const gy = Math.max(20, tl.y - 20);

        ctx.fillStyle = 'rgba(39, 42, 47, 0.97)';
        ctx.fillRect(gx - gw / 2, gy - 10, gw, 20);
        ctx.strokeStyle = '#4c9aff';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(gx - gw / 2, gy - 10, gw, 20);
        ctx.fillStyle = '#4c9aff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(groupLabel, gx, gy);
        ctx.restore();
      }
    }

    // 4d. Render Active CAD Marquee Selection Box (Window L->R Blue Solid vs Crossing R->L Green Dashed)
    if (marqueeBox && marqueePreview) {
      const s0 = mmToScreen(marqueeBox.startMm.x, marqueeBox.startMm.y, width, height);
      const s1 = mmToScreen(marqueeBox.currentMm.x, marqueeBox.currentMm.y, width, height);
      const rx = Math.min(s0.x, s1.x);
      const ry = Math.min(s0.y, s1.y);
      const rw = Math.abs(s1.x - s0.x);
      const rh = Math.abs(s1.y - s0.y);

      const isWindowMode = marqueePreview.mode === 'window';

      ctx.save();
      ctx.fillStyle = isWindowMode
        ? 'rgba(76, 154, 255, 0.16)'
        : 'rgba(76, 154, 255, 0.16)';
      ctx.strokeStyle = isWindowMode ? '#4c9aff' : '#4c9aff';
      ctx.lineWidth = 1.8;
      if (!isWindowMode) {
        ctx.setLineDash([6, 4]);
      }
      ctx.fillRect(rx, ry, rw, rh);
      ctx.strokeRect(rx, ry, rw, rh);
      ctx.setLineDash([]);

      const boxLabel = isWindowMode
        ? `蓝框包含选 (左→右): 完全框住才选中 · 命中 ${marqueePreview.selectedIds.length} 个`
        : `绿框交叉选 (右→左): 碰到边线即选中 · 命中 ${marqueePreview.selectedIds.length} 个`;
      ctx.font = '600 10.5px "JetBrains Mono", "Noto Sans SC", monospace';
      const lw = ctx.measureText(boxLabel).width + 12;
      const lx = rx + rw / 2;
      const ly = Math.max(18, ry - 12);

      ctx.fillStyle = 'rgba(39, 42, 47, 0.97)';
      ctx.fillRect(lx - lw / 2, ly - 9, lw, 18);
      ctx.strokeStyle = isWindowMode ? '#4c9aff' : '#4c9aff';
      ctx.lineWidth = 1;
      ctx.strokeRect(lx - lw / 2, ly - 9, lw, 18);
      ctx.fillStyle = isWindowMode ? '#4c9aff' : '#4c9aff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(boxLabel, lx, ly);
      ctx.restore();
    }

    // 5. Render active drawing preview with live CAD dimension annotations
    if (activeTool === 'polyline' && draftPoints.length > 0) {
      ctx.save();
      ctx.strokeStyle = '#4c9aff';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      draftPoints.forEach((pt, i) => {
        const s = mmToScreen(pt.x, pt.y, width, height);
        if (i === 0) ctx.moveTo(s.x, s.y);
        else ctx.lineTo(s.x, s.y);
      });
      const curScreen = mmToScreen(cursorMm.x, cursorMm.y, width, height);
      ctx.lineTo(curScreen.x, curScreen.y);
      ctx.stroke();

      draftPoints.forEach((pt, i) => {
        const s = mmToScreen(pt.x, pt.y, width, height);
        ctx.fillStyle = i === 0 ? '#a3abb8' : '#4c9aff';
        ctx.beginPath();
        ctx.arc(s.x, s.y, i === 0 ? 6 : 4.5, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();
    } else if (
      dragStartMm &&
      (activeTool === 'line' ||
        activeTool === 'rect' ||
        activeTool === 'triangle' ||
        activeTool === 'circle')
    ) {
      ctx.save();
      ctx.strokeStyle = '#4c9aff';
      ctx.fillStyle = 'rgba(76, 154, 255, 0.22)';
      ctx.lineWidth = 2.2;

      if (activeTool === 'line') {
        const wallPts = createLineWallPoints(dragStartMm, cursorMm, 8);
        ctx.beginPath();
        wallPts.forEach((pt, idx) => {
          const s = mmToScreen(pt.x, pt.y, width, height);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        const lenMm = Math.hypot(cursorMm.x - dragStartMm.x, cursorMm.y - dragStartMm.y);
        const areaMm2 = lenMm * 8;
        const curScreen = mmToScreen(cursorMm.x, cursorMm.y, width, height);
        ctx.fillStyle = '#4c9aff';
        ctx.font = '600 11px "JetBrains Mono", "Noto Sans SC", monospace';
        ctx.fillText(
          `长度 L=${lenMm.toFixed(1)}mm · 面积 S=${areaMm2.toFixed(0)}mm²`,
          curScreen.x + 10,
          curScreen.y - 10,
        );
      } else if (activeTool === 'rect') {
        const s0 = mmToScreen(dragStartMm.x, dragStartMm.y, width, height);
        const s1 = mmToScreen(cursorMm.x, cursorMm.y, width, height);
        const rx = Math.min(s0.x, s1.x);
        const ry = Math.min(s0.y, s1.y);
        const rw = Math.abs(s1.x - s0.x);
        const rh = Math.abs(s1.y - s0.y);
        ctx.fillRect(rx, ry, rw, rh);
        ctx.strokeRect(rx, ry, rw, rh);
      } else if (activeTool === 'triangle') {
        const w = Math.max(12, Math.abs(cursorMm.x - dragStartMm.x));
        const d = Math.max(12, Math.abs(cursorMm.y - dragStartMm.y));
        const cxMm = (cursorMm.x + dragStartMm.x) / 2;
        const cyMm = (cursorMm.y + dragStartMm.y) / 2;
        const triPts = createTrianglePoints(cxMm, cyMm, w, d);
        ctx.beginPath();
        triPts.forEach((pt, idx) => {
          const s = mmToScreen(pt.x, pt.y, width, height);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (activeTool === 'circle') {
        const radiusMm = Math.max(
          8,
          Math.hypot(cursorMm.x - dragStartMm.x, cursorMm.y - dragStartMm.y),
        );
        const previewPts = createRegularPolygonPoints(
          dragStartMm.x,
          dragStartMm.y,
          radiusMm,
          32,
        );
        ctx.beginPath();
        previewPts.forEach((pt, idx) => {
          const s = mmToScreen(pt.x, pt.y, width, height);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }

    // 5b. Boolean operation preview (blue dashed outline, not yet committed)
    if (booleanPreview && booleanPreview.points.length >= 3) {
      ctx.save();
      ctx.beginPath();
      booleanPreview.points.forEach((pt, idx) => {
        const s = mmToScreen(pt.x, pt.y, width, height);
        if (idx === 0) ctx.moveTo(s.x, s.y);
        else ctx.lineTo(s.x, s.y);
      });
      ctx.closePath();
      if (booleanPreview.holePoints && booleanPreview.holePoints.length >= 3) {
        booleanPreview.holePoints.forEach((pt, idx) => {
          const s = mmToScreen(pt.x, pt.y, width, height);
          if (idx === 0) ctx.moveTo(s.x, s.y);
          else ctx.lineTo(s.x, s.y);
        });
        ctx.closePath();
      }
      ctx.fillStyle = 'rgba(76, 154, 255, 0.16)';
      ctx.fill('evenodd');
      ctx.setLineDash([7, 4]);
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = '#4c9aff';
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    // 5c. Geometry snap indicator (端点□ / 中点△ / 圆心◎)
    if (geometrySnap) {
      const gs = mmToScreen(geometrySnap.point.x, geometrySnap.point.y, width, height);
      ctx.save();
      ctx.strokeStyle = '#4c9aff';
      ctx.fillStyle = 'rgba(76, 154, 255, 0.25)';
      ctx.lineWidth = 2;
      if (geometrySnap.kind === 'endpoint') {
        ctx.beginPath();
        ctx.rect(gs.x - 5, gs.y - 5, 10, 10);
        ctx.fill();
        ctx.stroke();
      } else if (geometrySnap.kind === 'midpoint') {
        ctx.beginPath();
        ctx.moveTo(gs.x, gs.y - 6);
        ctx.lineTo(gs.x + 6, gs.y + 5);
        ctx.lineTo(gs.x - 6, gs.y + 5);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(gs.x, gs.y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(gs.x - 9, gs.y);
        ctx.lineTo(gs.x + 9, gs.y);
        ctx.moveTo(gs.x, gs.y - 9);
        ctx.lineTo(gs.x, gs.y + 9);
        ctx.stroke();
      }
      const kindLabel =
        geometrySnap.kind === 'endpoint'
          ? '端点'
          : geometrySnap.kind === 'midpoint'
            ? '中点'
            : '圆心';
      drawHaloText(
        `捕捉${kindLabel} · ${geometrySnap.shapeName.replace(/\s*\(.*\)/, '')}`,
        gs.x,
        gs.y - 17,
        '#4c9aff',
        Math.max(9.5, adaptiveFontPx),
        600,
        3,
      );
      ctx.restore();
    }

    // 6. Snap cursor crosshair
    const curScreen = mmToScreen(cursorMm.x, cursorMm.y, width, height);
    ctx.strokeStyle = 'rgba(76, 154, 255, 0.45)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(curScreen.x - 8, curScreen.y);
    ctx.lineTo(curScreen.x + 8, curScreen.y);
    ctx.moveTo(curScreen.x, curScreen.y - 8);
    ctx.lineTo(curScreen.x, curScreen.y + 8);
    ctx.stroke();

    ctx.restore();
  }, [
    canvasSize,
    shapes,
    selectedId,
    selectedIds,
    selectedIdSet,
    selectedEdgeIndex,
    showDimensions,
    smartGuidesEnabled,
    displayedSnapGuides,
    marqueeBox,
    marqueePreview,
    zoom,
    pan,
    gridStep,
    activeTool,
    draftPoints,
    dragStartMm,
    cursorMm,
    draggingVertexIdx,
    draggingSingleEdge,
    draggingHoleVertexIdx,
    draggingResizeEdge,
    draggingWholeShape,
    defaultZHeight,
    booleanPreview,
    geometrySnap,
    mmToScreen,
  ]);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // Right-click or Middle-click or Alt+Left-click pans the 2D canvas
    if (e.button === 1 || e.button === 2 || (e.button === 0 && e.altKey)) {
      setIsPanning({ startX: e.clientX, startY: e.clientY, origPan: { ...pan } });
      return;
    }

    const rawMm = screenToMm(px, py, rect.width, rect.height, false);
    // 画图落点优先做几何捕捉（端点/中点/圆心），其次才是网格吸附
    const geoOnDown = snapEnabled
      ? findGeometrySnap(rawMm, shapes, Math.max(2.5, 7 / zoom))
      : null;
    const ptMm = geoOnDown
      ? { ...geoOnDown.point }
      : screenToMm(px, py, rect.width, rect.height, true);
    const isAdditive = e.ctrlKey || e.metaKey || e.shiftKey;

    if (activeTool === 'polyline') {
      if (draftPoints.length >= 3) {
        const firstScreen = mmToScreen(
          draftPoints[0].x,
          draftPoints[0].y,
          rect.width,
          rect.height,
        );
        if (Math.hypot(px - firstScreen.x, py - firstScreen.y) < 15) {
          commitPolyline();
          return;
        }
      }
      setDraftPoints((prev) => [...prev, ptMm]);
      return;
    }

    if (
      activeTool === 'line' ||
      activeTool === 'rect' ||
      activeTool === 'triangle' ||
      activeTool === 'circle'
    ) {
      setDragStartMm(ptMm);
      return;
    }

    // Tool === 'select'
    // 1. LEVEL 1 — 选点 (Vertex Handle ■ or Edge Resize Handle ● of the selected shape)
    if (selectedShape && selectedIds.length === 1 && !selectedShape.locked) {
      if (selectedShape.points.length <= 16) {
        for (let i = 0; i < selectedShape.points.length; i++) {
          const vScreen = mmToScreen(
            selectedShape.points[i].x,
            selectedShape.points[i].y,
            rect.width,
            rect.height,
          );
          if (Math.hypot(px - vScreen.x, py - vScreen.y) <= 10) {
            setDraggingVertexIdx(i);
            setSelectionModeLabel(`选点模式：正在拖拽顶点 #${i + 1}`);
            return;
          }
        }
      }

      const bounds = computeBounds2D(selectedShape.points);
      if (bounds.widthX >= 4 && bounds.depthY >= 4) {
        const edgeHandles: { side: ResizeEdgeSide; pt: Point2D }[] = [
          { side: 'left', pt: { x: bounds.minX, y: bounds.centroid.y } },
          { side: 'right', pt: { x: bounds.maxX, y: bounds.centroid.y } },
          { side: 'top', pt: { x: bounds.centroid.x, y: bounds.maxY } },
          { side: 'bottom', pt: { x: bounds.centroid.x, y: bounds.minY } },
        ];
        for (const h of edgeHandles) {
          const hs = mmToScreen(h.pt.x, h.pt.y, rect.width, rect.height);
          if (Math.hypot(px - hs.x, py - hs.y) <= 9) {
            setDraggingResizeEdge({
              shapeId: selectedShape.id,
              side: h.side,
              origPoints: selectedShape.points.map((p) => ({ ...p })),
              origHolePoints: selectedShape.holePoints?.map((p) => ({ ...p })),
              origBounds: bounds,
            });
            setSelectionModeLabel(`选边缩放：正在拖拽 ${h.side} 边缘控点`);
            return;
          }
        }
      }
    }

    // 2. LEVEL 2 — 选线 (Click/Drag directly on a shape's border line / edge within ~7px)
    const edgeToleranceMm = Math.max(2.2, 7 / zoom);
    const closestEdge = findClosestShapeEdge(rawMm, shapes, edgeToleranceMm);
    if (closestEdge && !isAdditive) {
      const targetShape = shapes.find((s) => s.id === closestEdge.shapeId);
      commitSelectedIds([closestEdge.shapeId]);
      setSelectedEdgeIndex(closestEdge.edgeIndex);
      setSelectionModeLabel(
        `选线模式：已选中 边#${closestEdge.edgeIndex + 1} (${closestEdge.edge.lengthMm}mm)，拖动可推拉该边`,
      );
      if (targetShape && !targetShape.locked && targetShape.points.length <= 16) {
        setDraggingSingleEdge({
          shapeId: targetShape.id,
          edgeIndex: closestEdge.edgeIndex,
          startMm: rawMm,
          origPoints: targetShape.points.map((p) => ({ ...p })),
        });
      }
      return;
    }

    // 3. LEVEL 3 — 选整体图形 / 多选移动 (Click inside a shape's fill area)
    for (let i = shapes.length - 1; i >= 0; i--) {
      const s = shapes[i];
      if (!s.visible) continue;
      if (isPointInPolygon(rawMm, s.points)) {
        setSelectedEdgeIndex(null);
        let nextSelectedIds: string[];
        if (isAdditive) {
          if (selectedIdSet.has(s.id)) {
            nextSelectedIds = selectedIds.filter((id) => id !== s.id);
          } else {
            nextSelectedIds = [...selectedIds, s.id];
          }
          commitSelectedIds(nextSelectedIds);
          setSelectionModeLabel(`多选模式：已选中 ${nextSelectedIds.length} 个图形`);
          return;
        }

        // If clicking inside an already batch-selected shape, keep the batch selection so all move together!
        nextSelectedIds =
          selectedIdSet.has(s.id) && selectedIds.length > 1
            ? selectedIds
            : [s.id];
        commitSelectedIds(nextSelectedIds);
        setSelectionModeLabel(
          nextSelectedIds.length > 1
            ? `批量移动：已选中 ${nextSelectedIds.length} 个图形`
            : `选整体图形：${s.name.replace(/\s*\(.*\)/, '')}`,
        );

        const origShapesMap: Record<
          string,
          { points: Point2D[]; holePoints?: Point2D[] }
        > = {};
        shapes.forEach((sh) => {
          if (nextSelectedIds.includes(sh.id) && !sh.locked) {
            origShapesMap[sh.id] = {
              points: sh.points.map((p) => ({ ...p })),
              holePoints: sh.holePoints?.map((p) => ({ ...p })),
            };
          }
        });

        setDraggingWholeShape({
          primaryShapeId: s.id,
          movingIds: nextSelectedIds,
          startMm: rawMm,
          origShapesMap,
        });
        return;
      }
    }

    // 4. LEVEL 4 — 空白处左键拖拽：启动 CAD 批量选取框 (左→右 蓝框包含选 / 右→左 绿框交叉选)
    setSelectedEdgeIndex(null);
    setActiveSnapGuides([]);
    setMarqueeBox({
      startMm: rawMm,
      currentMm: rawMm,
      additive: isAdditive,
    });
    setSelectionModeLabel('框选模式：向右拖=蓝框包含选，向左拖=绿框交叉选');
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    if (isPanning) {
      setPan({
        x: isPanning.origPan.x + (e.clientX - isPanning.startX),
        y: isPanning.origPan.y + (e.clientY - isPanning.startY),
      });
      return;
    }

    const rawMm = screenToMm(px, py, rect.width, rect.height, false);
    const ptMm = screenToMm(px, py, rect.width, rect.height, true);
    const snapTolMm = Math.max(2.5, 7 / zoom);

    // 0. Active CAD Marquee Selection Box drag
    if (marqueeBox) {
      setMarqueeBox((prev) => (prev ? { ...prev, currentMm: rawMm } : null));
      setCursorMm(ptMm);
      return;
    }

    // 1. Resizing a single vertex with Smart Snap Guides
    if (draggingVertexIdx !== null && selectedShape) {
      const smartSnap = computePointSnapGuides(
        rawMm,
        selectedShape.id,
        shapes,
        snapTolMm,
        smartGuidesEnabled,
        draggingVertexIdx,
      );
      const hasXGuide = smartSnap.guides.some((g) => g.axis === 'x');
      const hasYGuide = smartSnap.guides.some((g) => g.axis === 'y');
      const finalX = hasXGuide ? smartSnap.snappedPt.x : ptMm.x;
      const finalY = hasYGuide ? smartSnap.snappedPt.y : ptMm.y;

      setCursorMm({ x: finalX, y: finalY });
      setActiveSnapGuides(smartSnap.guides);

      const nextPts = selectedShape.points.map((p, idx) =>
        idx === draggingVertexIdx ? { x: finalX, y: finalY } : p,
      );
      const isTransient = dragHistoryPushedRef.current;
      dragHistoryPushedRef.current = true;
      onUpdateShape({ ...selectedShape, points: nextPts }, isTransient);
      return;
    }

    // 1b. Pushing/pulling a single selected edge (moves both endpoints of that edge)
    if (draggingSingleEdge) {
      const target = shapes.find((s) => s.id === draggingSingleEdge.shapeId);
      if (target) {
        const rawDx = rawMm.x - draggingSingleEdge.startMm.x;
        const rawDy = rawMm.y - draggingSingleEdge.startMm.y;
        if (Math.abs(rawDx) >= 1.5 || Math.abs(rawDy) >= 1.5) {
          const snappedDx = snapToGrid(rawDx, gridStep, snapEnabled);
          const snappedDy = snapToGrid(rawDy, gridStep, snapEnabled);
          const idxA = draggingSingleEdge.edgeIndex;
          const idxB = (idxA + 1) % draggingSingleEdge.origPoints.length;
          const nextPts = draggingSingleEdge.origPoints.map((p, idx) =>
            idx === idxA || idx === idxB
              ? {
                  x: Math.round((p.x + snappedDx) * 100) / 100,
                  y: Math.round((p.y + snappedDy) * 100) / 100,
                }
              : p,
          );
          const isTransient = dragHistoryPushedRef.current;
          dragHistoryPushedRef.current = true;
          onUpdateShape({ ...target, points: nextPts }, isTransient);
        }
      }
      setCursorMm(ptMm);
      return;
    }

    // 2. Resizing a bounding-box edge handle (left/right/top/bottom) with Smart Snap Guides
    if (draggingResizeEdge) {
      const target = shapes.find((s) => s.id === draggingResizeEdge.shapeId);
      if (target) {
        const smartSnap = computePointSnapGuides(
          rawMm,
          target.id,
          shapes,
          snapTolMm,
          smartGuidesEnabled,
        );
        const { side, origBounds, origPoints, origHolePoints } = draggingResizeEdge;
        const relevantGuides = smartSnap.guides.filter((g) =>
          side === 'left' || side === 'right' ? g.axis === 'x' : g.axis === 'y',
        );
        setActiveSnapGuides(relevantGuides);

        const snappedEdgeX = relevantGuides.some((g) => g.axis === 'x')
          ? smartSnap.snappedPt.x
          : ptMm.x;
        const snappedEdgeY = relevantGuides.some((g) => g.axis === 'y')
          ? smartSnap.snappedPt.y
          : ptMm.y;

        setCursorMm({ x: snappedEdgeX, y: snappedEdgeY });

        const scalePoint = (p: Point2D): Point2D => {
          let x = p.x;
          let y = p.y;
          if (side === 'right' && origBounds.widthX > 1) {
            const newW = Math.max(4, snappedEdgeX - origBounds.minX);
            x = origBounds.minX + ((p.x - origBounds.minX) / origBounds.widthX) * newW;
          } else if (side === 'left' && origBounds.widthX > 1) {
            const newMinX = Math.min(origBounds.maxX - 4, snappedEdgeX);
            const newW = origBounds.maxX - newMinX;
            x = origBounds.maxX - ((origBounds.maxX - p.x) / origBounds.widthX) * newW;
          } else if (side === 'top' && origBounds.depthY > 1) {
            const newD = Math.max(4, snappedEdgeY - origBounds.minY);
            y = origBounds.minY + ((p.y - origBounds.minY) / origBounds.depthY) * newD;
          } else if (side === 'bottom' && origBounds.depthY > 1) {
            const newMinY = Math.min(origBounds.maxY - 4, snappedEdgeY);
            const newD = origBounds.maxY - newMinY;
            y = origBounds.maxY - ((origBounds.maxY - p.y) / origBounds.depthY) * newD;
          }
          return {
            x: Math.round(x * 100) / 100,
            y: Math.round(y * 100) / 100,
          };
        };

        const isTransient = dragHistoryPushedRef.current;
        dragHistoryPushedRef.current = true;
        onUpdateShape(
          {
            ...target,
            points: origPoints.map(scalePoint),
            holePoints: origHolePoints?.map(scalePoint),
          },
          isTransient,
        );
      }
      return;
    }

    if (draggingHoleVertexIdx !== null && selectedShape && selectedShape.holePoints) {
      setCursorMm(ptMm);
      const nextHole = selectedShape.holePoints.map((p, idx) =>
        idx === draggingHoleVertexIdx ? { x: ptMm.x, y: ptMm.y } : p,
      );
      const isTransient = dragHistoryPushedRef.current;
      dragHistoryPushedRef.current = true;
      onUpdateShape({ ...selectedShape, holePoints: nextHole }, isTransient);
      return;
    }

    // 3. Moving single or batch-selected shapes with Smart Snap Guides
    if (draggingWholeShape) {
      const primaryOrig =
        draggingWholeShape.origShapesMap[draggingWholeShape.primaryShapeId];
      if (primaryOrig) {
        const rawDx = rawMm.x - draggingWholeShape.startMm.x;
        const rawDy = rawMm.y - draggingWholeShape.startMm.y;
        if (Math.abs(rawDx) < 0.05 && Math.abs(rawDy) < 0.05) return;

        const rawCandidatePts = primaryOrig.points.map((p) => ({
          x: p.x + rawDx,
          y: p.y + rawDy,
        }));

        const nonMovingShapes = shapes.filter(
          (s) => !draggingWholeShape.movingIds.includes(s.id),
        );
        const moveSnap = computeMoveSnapGuides(
          rawCandidatePts,
          draggingWholeShape.primaryShapeId,
          nonMovingShapes,
          snapTolMm,
          smartGuidesEnabled,
        );

        const hasXSnap = moveSnap.guides.some((g) => g.axis === 'x');
        const hasYSnap = moveSnap.guides.some((g) => g.axis === 'y');

        const finalDx = hasXSnap
          ? rawDx + moveSnap.snappedDelta.x
          : snapToGrid(rawDx, gridStep, snapEnabled);
        const finalDy = hasYSnap
          ? rawDy + moveSnap.snappedDelta.y
          : snapToGrid(rawDy, gridStep, snapEnabled);

        setActiveSnapGuides(moveSnap.guides);
        setCursorMm({
          x: Math.round((draggingWholeShape.startMm.x + finalDx) * 100) / 100,
          y: Math.round((draggingWholeShape.startMm.y + finalDy) * 100) / 100,
        });

        const isTransient = dragHistoryPushedRef.current;
        dragHistoryPushedRef.current = true;

        if (draggingWholeShape.movingIds.length > 1 && onUpdateMultipleShapes) {
          const nextShapes = shapes.map((s) => {
            const orig = draggingWholeShape.origShapesMap[s.id];
            if (!orig) return s;
            return {
              ...s,
              points: orig.points.map((p) => ({
                x: Math.round((p.x + finalDx) * 100) / 100,
                y: Math.round((p.y + finalDy) * 100) / 100,
              })),
              holePoints: orig.holePoints?.map((p) => ({
                x: Math.round((p.x + finalDx) * 100) / 100,
                y: Math.round((p.y + finalDy) * 100) / 100,
              })),
            };
          });
          onUpdateMultipleShapes(nextShapes, isTransient);
        } else {
          const target = shapes.find(
            (s) => s.id === draggingWholeShape.primaryShapeId,
          );
          if (target) {
            onUpdateShape(
              {
                ...target,
                points: primaryOrig.points.map((p) => ({
                  x: Math.round((p.x + finalDx) * 100) / 100,
                  y: Math.round((p.y + finalDy) * 100) / 100,
                })),
                holePoints: primaryOrig.holePoints?.map((p) => ({
                  x: Math.round((p.x + finalDx) * 100) / 100,
                  y: Math.round((p.y + finalDy) * 100) / 100,
                })),
              },
              isTransient,
            );
          }
        }
      }
      return;
    }

    // 4. Drawing new shape with Geometry Snap (端点/中点/圆心) + Smart Snap Guides
    if (dragStartMm || (activeTool === 'polyline' && draftPoints.length > 0)) {
      const geoSnap = snapEnabled
        ? findGeometrySnap(rawMm, shapes, snapTolMm)
        : null;
      setGeometrySnap(geoSnap);
      if (geoSnap) {
        // 几何捕捉命中：光标直接锁定到捕捉点，不再叠加对齐参考线
        setCursorMm({ ...geoSnap.point });
        setActiveSnapGuides([]);
        return;
      }
      const drawSnap = computePointSnapGuides(
        rawMm,
        null,
        shapes,
        snapTolMm,
        smartGuidesEnabled,
      );
      const hasX = drawSnap.guides.some((g) => g.axis === 'x');
      const hasY = drawSnap.guides.some((g) => g.axis === 'y');
      setCursorMm({
        x: hasX ? drawSnap.snappedPt.x : ptMm.x,
        y: hasY ? drawSnap.snappedPt.y : ptMm.y,
      });
      setActiveSnapGuides(drawSnap.guides);
      return;
    }

    // 5. Implicit Hover Detection (when idle in select mode: detect hovered edge or shape)
    if (activeTool === 'select') {
      const edgeHit = findClosestShapeEdge(rawMm, shapes, 6.5 / zoom);
      if (edgeHit) {
        setHoveredTarget((prev) =>
          prev.shapeId === edgeHit.shapeId && prev.edgeIndex === edgeHit.edgeIndex
            ? prev
            : { shapeId: edgeHit.shapeId, edgeIndex: edgeHit.edgeIndex },
        );
      } else {
        let foundShapeId: string | null = null;
        for (let i = shapes.length - 1; i >= 0; i--) {
          const s = shapes[i];
          if (!s.visible) continue;
          if (isPointInPolygon(rawMm, s.points)) {
            foundShapeId = s.id;
            break;
          }
        }
        setHoveredTarget((prev) =>
          prev.shapeId === foundShapeId && prev.edgeIndex === null
            ? prev
            : { shapeId: foundShapeId, edgeIndex: null },
        );
      }
    }

    // Idle / select-mode: 同样计算几何捕捉指示，帮助用户找到精确落点
    setGeometrySnap(
      snapEnabled ? findGeometrySnap(rawMm, shapes, snapTolMm) : null,
    );
    setCursorMm(ptMm);
  };

  const handleMouseUp = () => {
    dragHistoryPushedRef.current = false;
    setActiveSnapGuides([]);
    if (isPanning) {
      setIsPanning(null);
      return;
    }
    if (marqueeBox) {
      const dragDistMm = Math.hypot(
        marqueeBox.currentMm.x - marqueeBox.startMm.x,
        marqueeBox.currentMm.y - marqueeBox.startMm.y,
      );
      if (dragDistMm >= 2) {
        const result = computeBoxSelectedShapeIds(
          marqueeBox.startMm,
          marqueeBox.currentMm,
          shapes,
        );
        const nextIds = marqueeBox.additive
          ? Array.from(new Set([...selectedIds, ...result.selectedIds]))
          : result.selectedIds;
        commitSelectedIds(nextIds);
        setSelectionModeLabel(
          result.mode === 'window'
            ? `蓝框包含选完成：共选中 ${nextIds.length} 个图形`
            : `绿框交叉选完成：共选中 ${nextIds.length} 个图形`,
        );
      } else if (!marqueeBox.additive) {
        commitSelectedIds([]);
        setSelectionModeLabel('已取消选中 (点击图形或空白拖拽框选)');
      }
      setMarqueeBox(null);
      return;
    }
    if (draggingVertexIdx !== null) {
      setDraggingVertexIdx(null);
      return;
    }
    if (draggingSingleEdge !== null) {
      setDraggingSingleEdge(null);
      return;
    }
    if (draggingResizeEdge !== null) {
      setDraggingResizeEdge(null);
      return;
    }
    if (draggingHoleVertexIdx !== null) {
      setDraggingHoleVertexIdx(null);
      return;
    }
    if (draggingWholeShape) {
      setDraggingWholeShape(null);
      return;
    }

    if (dragStartMm) {
      const dist = Math.hypot(cursorMm.x - dragStartMm.x, cursorMm.y - dragStartMm.y);

      if (activeTool === 'line') {
        const endPt =
          dist < 5 ? { x: dragStartMm.x + 40, y: dragStartMm.y } : cursorMm;
        onCreateShape({
          id: `cad-line-${Date.now()}`,
          name: `直线墙 #${shapes.length + 1}`,
          type: 'line',
          points: createLineWallPoints(dragStartMm, endPt, 8),
          zHeight: defaultZHeight,
          zOffset: 0,
          bevel: 0.4,
          color: '#A5ADB8',
          materialPreset: 'steel',
          visible: true,
        });
      } else if (activeTool === 'rect') {
        const w = dist < 5 ? 36 : Math.max(10, Math.abs(cursorMm.x - dragStartMm.x));
        const d = dist < 5 ? 36 : Math.max(10, Math.abs(cursorMm.y - dragStartMm.y));
        const cx = dist < 5 ? dragStartMm.x : (cursorMm.x + dragStartMm.x) / 2;
        const cy = dist < 5 ? dragStartMm.y : (cursorMm.y + dragStartMm.y) / 2;
        onCreateShape({
          id: `cad-rect-${Date.now()}`,
          name: `方块 #${shapes.length + 1}`,
          type: 'rect',
          points: createRectanglePoints(cx, cy, w, d),
          zHeight: defaultZHeight,
          zOffset: 0,
          bevel: 0.8,
          color: '#A5ADB8',
          materialPreset: 'aluminum',
          visible: true,
        });
      } else if (activeTool === 'triangle') {
        const w = dist < 5 ? 40 : Math.max(12, Math.abs(cursorMm.x - dragStartMm.x));
        const d = dist < 5 ? 36 : Math.max(12, Math.abs(cursorMm.y - dragStartMm.y));
        const cx = dist < 5 ? dragStartMm.x : (cursorMm.x + dragStartMm.x) / 2;
        const cy = dist < 5 ? dragStartMm.y : (cursorMm.y + dragStartMm.y) / 2;
        onCreateShape({
          id: `cad-tri-${Date.now()}`,
          name: `三角柱 #${shapes.length + 1}`,
          type: 'triangle',
          points: createTrianglePoints(cx, cy, w, d),
          zHeight: defaultZHeight,
          zOffset: 0,
          bevel: 0.8,
          color: '#A5ADB8',
          materialPreset: 'plastic',
          visible: true,
        });
      } else if (activeTool === 'circle') {
        const r = dist < 5 ? 18 : Math.max(8, Math.round(dist));
        onCreateShape({
          id: `cad-circle-${Date.now()}`,
          name: `圆柱 #${shapes.length + 1}`,
          type: 'circle',
          points: createRegularPolygonPoints(dragStartMm.x, dragStartMm.y, r, 32),
          zHeight: defaultZHeight,
          zOffset: 0,
          bevel: 0.8,
          color: '#A5ADB8',
          materialPreset: 'brass',
          visible: true,
        });
      }
      setDragStartMm(null);
      setSizeInput('');
      setGeometrySnap(null);
      onChangeTool('select');
    }
  };

  // 精确尺寸提交：拖画起点已定，直接键入尺寸回车生成图形
  const commitExactSize = useCallback(() => {
    if (!dragStartMm) return;
    const raw = sizeInput.trim();
    if (!raw) return;
    const num = (s: string) => Number(s.trim());

    if (activeTool === 'rect' || activeTool === 'triangle') {
      const m = raw.match(/^(\d+(?:\.\d+)?)\s*[xX×*,，]\s*(\d+(?:\.\d+)?)$/);
      if (!m) return;
      const w = Math.max(4, num(m[1]));
      const d = Math.max(4, num(m[2]));
      const isRect = activeTool === 'rect';
      onCreateShape({
        id: `cad-${activeTool}-${Date.now()}`,
        name: `${isRect ? '方块' : '三角柱'} #${shapes.length + 1}`,
        type: activeTool,
        points: isRect
          ? createRectanglePoints(dragStartMm.x, dragStartMm.y, w, d)
          : createTrianglePoints(dragStartMm.x, dragStartMm.y, w, d),
        zHeight: defaultZHeight,
        zOffset: 0,
        bevel: 0.8,
        color: '#A5ADB8',
        materialPreset: isRect ? 'aluminum' : 'plastic',
        visible: true,
      });
    } else if (activeTool === 'circle') {
      const m = raw.match(/^[ØoO]?\s*(\d+(?:\.\d+)?)$/);
      if (!m) return;
      const r = Math.max(2, num(m[1]) / 2);
      onCreateShape({
        id: `cad-circle-${Date.now()}`,
        name: `圆柱 #${shapes.length + 1}`,
        type: 'circle',
        points: createRegularPolygonPoints(dragStartMm.x, dragStartMm.y, r, 32),
        zHeight: defaultZHeight,
        zOffset: 0,
        bevel: 0.8,
        color: '#A5ADB8',
        materialPreset: 'brass',
        visible: true,
      });
    } else if (activeTool === 'line') {
      const m = raw.match(/^(\d+(?:\.\d+)?)\s*(?:[,，]\s*(-?\d+(?:\.\d+)?))?\s*(?:°|deg)?$/);
      if (!m) return;
      const len = Math.max(2, num(m[1]));
      const angleDeg = m[2] !== undefined ? num(m[2]) : 0;
      const rad = (angleDeg * Math.PI) / 180;
      const endPt = {
        x: dragStartMm.x + Math.cos(rad) * len,
        y: dragStartMm.y + Math.sin(rad) * len,
      };
      onCreateShape({
        id: `cad-line-${Date.now()}`,
        name: `直线墙 #${shapes.length + 1}`,
        type: 'line',
        points: createLineWallPoints(dragStartMm, endPt, 8),
        zHeight: defaultZHeight,
        zOffset: 0,
        bevel: 0.4,
        color: '#A5ADB8',
        materialPreset: 'steel',
        visible: true,
      });
    } else {
      return;
    }
    setDragStartMm(null);
    setSizeInput('');
    setGeometrySnap(null);
    onChangeTool('select');
  }, [
    dragStartMm,
    sizeInput,
    activeTool,
    shapes.length,
    defaultZHeight,
    onCreateShape,
    onChangeTool,
  ]);

  const activeEdgeIdxForHud =
    hoveredTarget.shapeId === selectedId && hoveredTarget.edgeIndex !== null
      ? hoveredTarget.edgeIndex
      : selectedEdgeIndex;

  const activeSelectedEdge =
    selectedDimensions &&
    activeEdgeIdxForHud !== null &&
    selectedDimensions.edges[activeEdgeIdxForHud]
      ? selectedDimensions.edges[activeEdgeIdxForHud]
      : null;

  const cycleAnnotationMode = () => {
    setAnnotationMode((prev) =>
      prev === 'adaptive' ? 'all' : prev === 'all' ? 'hidden' : 'adaptive',
    );
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full flex flex-col bg-[#1b1d21] select-none overflow-hidden"
    >
      <div className="h-9 px-3 flex items-center justify-between gap-3 bg-[var(--paper)] border-b border-[var(--line)] shrink-0 z-10 overflow-x-auto">
        <div className="flex items-center gap-2 shrink-0"><span className="text-[11px] font-semibold text-[var(--ink)]">二维草图</span><span className="text-[10px] text-[var(--muted)] font-mono">XY / mm</span></div>
        <div className="flex items-center gap-1 shrink-0">
          {activeTool === 'polyline' && draftPoints.length > 0 && <>
            <button type="button" onClick={commitPolyline} disabled={draftPoints.length < 2} className="h-6 px-2 rounded text-[11px] bg-[var(--blue)] text-[#101720] disabled:opacity-40">完成</button>
            <button type="button" onClick={() => setDraftPoints([])} title="取消多边形" aria-label="取消多边形" className="p-1 text-[var(--muted)] hover:bg-[var(--surface)] rounded"><X className="w-3.5 h-3.5" /></button>
          </>}
          <button type="button" onClick={() => setSmartGuidesEnabled(v => !v)} aria-label="切换智能对齐参考线" title="智能对齐" aria-pressed={smartGuidesEnabled} className={`p-1 rounded ${smartGuidesEnabled ? 'text-[var(--blue)] bg-[var(--selection)]' : 'text-[var(--muted)] hover:bg-[var(--surface)]'}`}><Magnet className="w-3.5 h-3.5" /></button>
          <button type="button" onClick={cycleAnnotationMode} aria-label="切换CAD尺寸注释模式" title="尺寸标注：自动 / 全部边 / 隐藏" className="h-6 px-2 text-[11px] text-[var(--muted)] hover:bg-[var(--surface)] rounded">标注 {annotationMode === 'adaptive' ? '自动' : annotationMode === 'all' ? '全部' : '关'}</button>
          <button type="button" onClick={onToggleSnap} aria-label="切换网格吸附" aria-pressed={snapEnabled} title="网格吸附" className={`h-6 px-2 text-[11px] rounded ${snapEnabled ? 'text-[var(--blue)] bg-[var(--selection)]' : 'text-[var(--muted)] hover:bg-[var(--surface)]'}`}>吸附 {snapEnabled ? `${gridStep} mm` : '关'}</button>
          <button type="button" onClick={() => setShowMouseGuide(v => !v)} aria-label="切换鼠标选点选线框选指南" title="操作提示" className="p-1 text-[var(--muted)] hover:bg-[var(--surface)] rounded"><HelpCircle className="w-3.5 h-3.5" /></button>
          <button type="button" onClick={() => { setZoom(2.8); setPan({ x: 0, y: 0 }); }} aria-label="重置XY二维视图" title="重置视图" className="p-1 text-[var(--muted)] hover:bg-[var(--surface)] rounded"><Maximize2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      {/* CAD Mouse Selection Guide Bar (On-Demand Toggle) */}
      {showMouseGuide && activeTool === 'select' && (
        <div
          data-testid="cad-mouse-guide"
          className="hidden sm:flex items-center justify-between gap-2 px-3 py-1 bg-[var(--paper)] border-b border-[var(--line)] text-[11px] font-mono text-[var(--muted)] flex-wrap shrink-0 z-10"
        >
          <div className="flex items-center gap-x-2.5 gap-y-1 flex-wrap">
            <span>
              <strong className="text-[var(--blue)]">1.选点(■):</strong> 拖方点改单角
            </span>
            <span className="text-[var(--muted)]">|</span>
            <span>
              <strong className="text-[var(--blue)]">2.选线(━):</strong> 悬停/点边测长，拖边推拉
            </span>
            <span className="text-[var(--muted)]">|</span>
            <span>
              <strong className="text-[var(--ink)]">3.选整体:</strong> 点内部移动(Ctrl多选)
            </span>
            <span className="text-[var(--muted)]">|</span>
            <span>
              <strong className="text-[var(--blue)]">4.左→右拖(蓝框):</strong> 全包选中
            </span>
            <span className="text-[var(--muted)]">|</span>
            <span>
              <strong className="text-[var(--blue)]">5.右→左拖(虚线):</strong> 碰到即选
            </span>
          </div>
          <span className="text-[var(--muted)] whitespace-nowrap shrink-0">
            右键拖拽:平移 · 滚轮:缩放
          </span>
        </div>
      )}

      {/* Main 2D XY Interactive Canvas */}
      <div className="relative flex-1 min-h-0 w-full">
        <canvas
          ref={canvasRef}
          data-testid="cad-2d-canvas"
          onContextMenu={(e) => e.preventDefault()}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => setHoveredTarget({ shapeId: null, edgeIndex: null })}
          onWheel={(e) => {
            const delta = e.deltaY < 0 ? 1.12 : 0.89;
            setZoom((z) => Math.min(10, Math.max(0.8, Math.round(z * delta * 100) / 100)));
          }}
          className={`w-full h-full block ${
            activeTool === 'select' ? 'cursor-default' : 'cursor-crosshair'
          }`}
        />

        {/* Exact-Size Input Bar: 拖画矩形/圆/直线/三角时可直接键入精确尺寸 */}
        {dragStartMm &&
          (activeTool === 'rect' ||
            activeTool === 'circle' ||
            activeTool === 'line' ||
            activeTool === 'triangle') && (
            <div
              data-testid="exact-size-input-bar"
              className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 px-3 py-1.5 bg-[var(--paper)] border border-[var(--line)] rounded-lg shadow-xl backdrop-blur"
            >
              <span className="text-[11px] font-mono text-[var(--blue)] font-semibold whitespace-nowrap">
                精确尺寸:
              </span>
              <input
                data-testid="exact-size-input"
                autoFocus
                type="text"
                value={sizeInput}
                onChange={(e) => setSizeInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    e.stopPropagation();
                    commitExactSize();
                  } else if (e.key === 'Escape') {
                    e.stopPropagation();
                    setDragStartMm(null);
                    setSizeInput('');
                    onChangeTool('select');
                  }
                }}
                placeholder={
                  activeTool === 'circle'
                    ? '直径 Ø mm，如 40（起点=圆心）'
                    : activeTool === 'line'
                      ? '长度[,角度°]，如 80 或 80,45'
                      : '宽×高 mm，如 80×50（起点=中心）'
                }
                className="w-64 bg-[var(--paper)] border border-[var(--line)] rounded px-2 py-1 text-xs font-mono text-[var(--blue)] placeholder:text-[var(--muted)] focus:outline-none focus:border-[var(--line)]"
              />
              <button
                type="button"
                onClick={commitExactSize}
                className="px-2.5 py-1 rounded bg-[var(--blue)] hover:bg-[var(--blue)] text-[#101720] text-xs font-bold whitespace-nowrap"
              >
                应用
              </button>
              <span className="text-[10px] font-mono text-[var(--muted)] whitespace-nowrap hidden xl:inline">
                回车应用 · Esc取消 · 或直接拖放鼠标
              </span>
            </div>
          )}

        {/* Top-Left Smart Snap Status Readout (strictly transient while dragging) */}
        {smartGuidesEnabled && displayedSnapGuides.length > 0 && (
          <div
            data-testid="smart-snap-status"
            className="absolute top-2 left-2.5 pointer-events-none flex items-center gap-1.5 text-[10.5px] font-mono bg-[var(--paper)] border border-[var(--line)] text-[var(--blue)] px-2 py-0.5 rounded shadow max-w-[90%]"
          >
            <Magnet className="w-3 h-3 text-[var(--blue)] shrink-0" />
            <span className="truncate">
              智能对齐: {displayedSnapGuides.map((g) => g.label).join(' · ')}
            </span>
          </div>
        )}

        {/* Empty Canvas Helpful Prompt */}
        {shapes.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-[var(--paper)] border border-[var(--line)] rounded-xl px-5 py-4 text-center max-w-sm shadow-xl">
              <div className="text-sm font-semibold text-[var(--blue)]">
                当前画布为空
              </div>
              <div className="text-xs text-[var(--muted)] mt-1 leading-relaxed">
                请点击上方控制台的 <strong>画直线 / 画矩形 / 画三角形 / 画圆形</strong> 在此处点击绘制，或直接点 <strong>+方块 / +三角 / +圆柱</strong> 一键生成！
              </div>
            </div>
          </div>
        )}

        {/* Bottom-Left Coordinate Readout */}
        <div className="absolute bottom-2 left-2.5 pointer-events-none text-[11px] font-mono text-[var(--muted)] bg-[var(--paper)] border border-[var(--line)] px-2 py-0.5 rounded flex items-center gap-1.5 w-fit backdrop-blur-sm">
          <span>XY:</span>
          <span className="text-[var(--blue)] tabular-nums">
            {cursorMm.x.toFixed(0)}, {cursorMm.y.toFixed(0)}mm
          </span>
        </div>

        {/* Bottom-Right Compact Implicit/Adaptive Dimension Pill (Single-line by default, expandable with editable edge inputs) */}
        {selectedDimensions && selectedShape && showDimensions && (
          <div
            data-testid="cad-dimension-hud"
            className="absolute bottom-2 right-2.5 z-10 bg-[var(--paper)] border border-[var(--line)] rounded-md px-2.5 py-1 shadow-sm max-w-[calc(100%-150px)] backdrop-blur-sm text-[11px] font-mono"
          >
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[var(--blue)] font-semibold truncate max-w-[120px] sm:max-w-[160px]">
                {selectedIds.length > 1
                  ? `已选${selectedIds.length}个`
                  : selectedDimensions.shapeName.replace(/\s*\(.*\)/, '')}
              </span>
              <span className="text-[var(--muted)]">·</span>
              {selectedDimensions.isLineFeature ? (
                <label className="flex items-center gap-1 text-[var(--blue)] tabular-nums">
                  <span>L=</span>
                  <input
                    data-testid="hud-line-length-input"
                    type="number"
                    min={2}
                    max={500}
                    step={1}
                    value={selectedDimensions.primaryLengthMm}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (val >= 2) {
                        onUpdateShape(
                          resizeLineWall2D(
                            selectedShape,
                            val,
                            selectedDimensions.thicknessMm,
                          ),
                        );
                      }
                    }}
                    className="w-13 bg-[var(--paper)] border border-[var(--line)] rounded px-1 py-0.2 text-[11px] text-[var(--blue)] text-right tabular-nums focus:outline-none focus:border-[var(--line)]"
                  />
                  <span>mm</span>
                </label>
              ) : selectedDimensions.shapeType === 'circle' ? (
                <label className="flex items-center gap-1 text-[var(--blue)] tabular-nums">
                  <span>Ø=</span>
                  <input
                    data-testid="hud-circle-diameter-input"
                    type="number"
                    min={2}
                    max={500}
                    step={1}
                    value={selectedDimensions.diameterMm ?? 30}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (val >= 2) {
                        onUpdateShape(
                          resizeCircleDiameter2D(selectedShape, val),
                        );
                      }
                    }}
                    className="w-13 bg-[var(--paper)] border border-[var(--line)] rounded px-1 py-0.2 text-[11px] text-[var(--blue)] text-right tabular-nums focus:outline-none focus:border-[var(--line)]"
                  />
                  <span>mm</span>
                </label>
              ) : (
                <span className="text-[var(--muted)] tabular-nums">
                  {selectedDimensions.widthX.toFixed(0)}×{selectedDimensions.depthY.toFixed(0)}mm
                </span>
              )}
              {/* Active Hovered or Clicked Edge Inline Customizer */}
              {activeSelectedEdge && !selectedDimensions.isLineFeature && selectedDimensions.shapeType !== 'circle' && (
                <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[var(--selection)] border border-[var(--line)] text-[var(--blue)] font-semibold tabular-nums">
                  <span>边{activeSelectedEdge.edgeIndex + 1}:</span>
                  <input
                    data-testid="canvas-edge-length-input"
                    aria-label={`修改边${activeSelectedEdge.edgeIndex + 1}长度`}
                    type="number"
                    min={1}
                    max={1000}
                    step={1}
                    value={activeSelectedEdge.lengthMm}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (Number.isFinite(val) && val >= 1) {
                        onUpdateShape(
                          resizeShapeEdge2D(
                            selectedShape,
                            activeSelectedEdge.edgeIndex,
                            val,
                          ),
                        );
                      }
                    }}
                    className="w-13 bg-[var(--paper)] border border-[var(--line)] rounded px-1 py-0 text-[11px] text-[var(--blue)] text-right tabular-nums focus:outline-none focus:border-[var(--line)]"
                  />
                  <span>mm</span>
                  <span className="text-[var(--blue)] text-[10px]">
                    ∠{activeSelectedEdge.angleDeg}°
                  </span>
                </div>
              )}

              {selectedIds.length === 1 &&
                !selectedDimensions.isLineFeature &&
                selectedDimensions.shapeType !== 'circle' &&
                selectedDimensions.edges.length <= 12 && (
                  <button
                    type="button"
                    data-testid="toggle-edge-list-hud"
                    onClick={() => setShowEdgeListHud((prev) => !prev)}
                    className={`ml-auto px-1.5 py-0.5 rounded border text-[10px] transition-colors ${
                      showEdgeListHud
                        ? 'bg-[var(--selection)] text-[var(--blue)] border-[var(--line)]'
                        : 'bg-[var(--surface)] hover:bg-[var(--surface)] text-[var(--blue)] border-[var(--line)]'
                    }`}
                    title="展开或收起各边数值自定义输入框"
                  >
                    {showEdgeListHud
                      ? '收起各边'
                      : `各边(${selectedDimensions.edges.length})·改值`}
                  </button>
                )}
            </div>

            {/* Expandable Per-Edge Numeric Customization Inputs */}
            {showEdgeListHud &&
              selectedIds.length === 1 &&
              !selectedDimensions.isLineFeature &&
              selectedDimensions.shapeType !== 'circle' &&
              selectedDimensions.edges.length <= 12 && (
                <div
                  data-testid="hud-edge-inputs-list"
                  className="mt-1.5 pt-1.5 border-t border-[var(--line)] flex items-center gap-1.5 flex-wrap"
                >
                  <span className="text-[10px] text-[var(--muted)] mr-0.5">
                    自定义各边(mm):
                  </span>
                  {selectedDimensions.edges.map((edge) => {
                    const isActive = activeEdgeIdxForHud === edge.edgeIndex;
                    return (
                      <div
                        key={edge.edgeIndex}
                        onMouseEnter={() =>
                          setHoveredTarget({
                            shapeId: selectedShape.id,
                            edgeIndex: edge.edgeIndex,
                          })
                        }
                        onMouseLeave={() =>
                          setHoveredTarget((prev) =>
                            prev.edgeIndex === edge.edgeIndex
                              ? { shapeId: null, edgeIndex: null }
                              : prev,
                          )
                        }
                        className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono border transition-colors ${
                          isActive
                            ? 'bg-[var(--selection)] border-[var(--line)] text-[var(--blue)]'
                            : 'bg-[var(--paper)] border-[var(--line)] text-[var(--muted)]'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() =>
                            setSelectedEdgeIndex(
                              selectedEdgeIndex === edge.edgeIndex
                                ? null
                                : edge.edgeIndex,
                            )
                          }
                          className="font-semibold hover:text-[var(--blue)]"
                          title={`点击在画布上锁定高亮 边${edge.edgeIndex + 1} (角度 ${edge.angleDeg}°)`}
                        >
                          边{edge.edgeIndex + 1}:
                        </button>
                        <input
                          data-testid={`hud-edge-input-${edge.edgeIndex}`}
                          aria-label={`边${edge.edgeIndex + 1}长度数值(mm)`}
                          type="number"
                          min={1}
                          max={1000}
                          step={1}
                          value={edge.lengthMm}
                          onFocus={() => setSelectedEdgeIndex(edge.edgeIndex)}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            if (Number.isFinite(val) && val >= 1) {
                              onUpdateShape(
                                resizeShapeEdge2D(
                                  selectedShape,
                                  edge.edgeIndex,
                                  val,
                                ),
                              );
                            }
                          }}
                          className="w-12 bg-[var(--paper)] border border-[var(--line)] rounded px-1 py-0 text-[10px] text-[var(--blue)] text-right tabular-nums focus:outline-none focus:border-[var(--line)]"
                        />
                      </div>
                    );
                  })}
                </div>
              )}
          </div>
        )}
      </div>
    </div>
  );
};

